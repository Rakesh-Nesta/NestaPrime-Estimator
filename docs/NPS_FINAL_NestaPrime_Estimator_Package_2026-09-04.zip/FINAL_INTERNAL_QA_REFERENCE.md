# NestaPrime Estimator — Internal QA Reference (formerly the Independent Re-Audit Engagement Brief)

**No longer a gate — Director decision, v5.1.11.** This document used to block Phase 1b until an
external reviewer signed it. The compliance risk that justified that — a wrong 194C deduction or a
misclassified GST rate at scale — no longer exists at v5.1.9's reduced scope, so the Director closed
Gate 1 by internal judgment rather than requiring an outside sign-off. What follows is kept as a
plain internal QA checklist: useful for whoever builds or reviews the code, not something anyone
needs to sign before proceeding. Everything this document used to ask a reviewer to check — 194C
arithmetic, GST-TDS s.51, multi-state place-of-supply, HSN classification, the separate-goods
carve-out — **no longer exists in the app**, because the app no longer attempts any of it.

## 0. What's worth checking (informally, whenever convenient)

That the implementation matches v5.1.9's actual (small) scope:
1. The quotation computes **Subtotal → flat 18% GST → Total**, correctly, and nothing else.
2. The total is presented to the client as **GST-inclusive**.
3. **No other GST or tax logic exists anywhere in the app** — no TDS, no HSN lookup, no
   place-of-supply computation, no per-line classification, no separate-goods flag.

That's the whole audit. It is a correctness-and-absence check, not a compliance-logic review.

## 1. What to attach

| # | File | Why the reviewer needs it |
|---|---|---|
| 1 | `FINAL_NESTAPRIME_MASTER_BLUEPRINT_v5.1.9.md` | Spec of record. K.4 and K.1b are the only sections under test |
| 2 | `RE_AUDIT_GUIDE.md` | *[NestaPrime: attach your existing guide if it covers anything beyond GST/TDS — engine calculations, role visibility, the M.2 document chain, etc. Nothing in it about TDS or multi-state GST is relevant any more]* |
| 3 | Read access to the Phase 1a repo at the commit under test | The reviewer needs to see that the removed logic is actually absent from the code, not just untested — a codebase that still contains dead 194C/HSN branches is a real finding even if nothing calls them |
| 4 | Reference: `23-A100-Quotation for Squash Court- Sanmati HS School.pdf` | NestaPrime's own real quotation — the pattern the app must match exactly (Subtotal → GST 18% flat → Total, inclusive) |

**No longer attached, and why:**
- `RE_AUDIT_GUIDE_TDS_ADDENDUM.md` — retired. Its 87-case TDS/GST-TDS/multi-state test matrix tests logic that no longer exists. Kept on file as a historical record only (see its own retirement note), not part of this audit's scope.
- `test_gst_logic_tds.py` — same reason. If this file is still present in the repo at audit time, its presence is itself worth flagging (dead test code for removed functionality).
- `NestaPrime_Rate_Card_Import_Template.xlsx` / rate-card spec — unrelated to this audit. Their relevance is to Gate 2 (rate-card load), not Gate 1.

## 2. Scope — the whole thing fits in one table now

| Case | Setup | Correct behaviour | What a wrong build does |
|---|---|---|---|
| G1 | Any quotation, any project type | Total = Subtotal × 1.18, computed server-side | Any other formula, or a client-editable GST field |
| G2 | Quotation PDF | Shows Subtotal, "GST 18%" as one line with its rupee amount, Total — GST-inclusive, matching the Sanmati precedent's layout | Shows a different structure, hides the GST line, or shows GST as excluded when the total is meant to be inclusive |
| G3 | Search the codebase for `194C`, `hsn_sac`, `place_of_supply`, `separate_goods_invoice`, `itds`, `tds` | **None of these should resolve to live, called code.** Dead code, migration remnants, or commented-out logic are lower-severity findings than a live code path, but still worth listing | A live function still computing TDS or HSN rates, even if nothing currently calls it from the UI — that's a landmine for whoever touches this code next |
| G4 | Any client-facing document (Estimate, Quotation) | Never shows HSN/SAC, GSTIN, place-of-supply state, or an ITC note — none of that belongs on a pre-sales pitch document per v5.1.9 | Any of the above appears, even as leftover template text |

That's the entire test surface. There is no G5.

## 3. What "pass" means

G1–G4 all hold, **and** the reviewer can point to the specific code that computes G1 and confirm no dead branch implements the removed logic (G3). A passing test suite alone doesn't establish G3 — that needs someone to actually read the code, which is exactly why §1 asks for repo access, not just test output.

## 4. Optional record (not required — no gate to close)

| Checked by (name, role) | Date | Commit hash under test | Sections passed | Notes |
|---|---|---|---|---|
| | | | | |

This table is here only if someone wants a record of having done the check — nothing depends on it
being filled in. **The one formal gate remaining before Phase 1b** is the rate-card load: NestaPrime
loads real vendor rates and labour cards into `NestaPrime_Rate_Card_Import_Template.xlsx` so the
*estimation engine* (court sizing, base/sub-base, structure, material consumption — the app's actual
product) prices accurately. That's an estimation-accuracy step, not a compliance one.
