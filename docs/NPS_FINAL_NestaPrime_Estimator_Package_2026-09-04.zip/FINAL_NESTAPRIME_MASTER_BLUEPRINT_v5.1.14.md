# NESTAPRIME ESTIMATOR - UNIFIED MASTER BLUEPRINT v5.1 (APP-READY BASELINE)

**Complete Sports Infrastructure Cost, Estimate & Quotation System — Single Source of Truth**

| | |
|---|---|
| Company | NestaPrime Sports Infrastructure |
| Status | Internal Use Only — **App-ready baseline.** Three independent audits (v4.1, v4.7 GST, v4.8 deep re-audit) plus four self-audits applied; all 7 critical v4.8 findings resolved in this version. Development may start on Phase 1a; Phase 1b and go-live conditions in Part R.0 |
| Version | **5.1.14** (Unified — supersedes v2 Blueprint, Vision Charter, v3 Unified. History: 4.1–4.3 audit corrections; 4.4 Master Settings; 4.5 second independent audit; 4.6 Kimi audit response; 4.7 re-audit watch-items; 4.8 GST recheck; **5.1.14 settles mobile delivery as a PWA (P.1), not a separate native app — one codebase, always-current build (a sideloaded APK doesn't auto-update, which matters given how often Master Settings changes are meant to take effect immediately); moves PWA from the Phase 7 "someday" slot into Phase 3, where the production quoting system actually ships; 5.1.13 removes Gate 2 (bulk rate-card load) as a hard blocker — Director decision, same reasoning as Gate 1's removal: the app already runs correctly on manual per-quotation rate entry with PM/Director confirmation (J.1) from day one; a pre-loaded rate card is a convenience to add gradually, not a prerequisite. Neither formal gate now blocks Phase 1b; Part R.0's checklist is recommended, not blocking; 5.1.12 adds Billing Handoff (J.4) — a "Send to Billing" button on a Won quotation, one-click PDF/Excel with client details, payment schedule and GST-inclusive total only, for NestaPrime to manually enter into Tally; no API integration, no new database entity; replaces the old CSV/ERP-with-HSN export line, which no longer matches v5.1.9's scope; 5.1.11 removes the Gate 1 independent-re-audit requirement (Part R.0) — Director decision, given the compliance risk that justified an external reviewer no longer exists at v5.1.9's reduced scope; the engagement brief becomes an informal internal QA reference, not a blocking gate; Gate 2 (rate-card load) is now the only formal gate before Phase 1b; 5.1.10 tightens K.1b's Supply Only wording: one blended ₹/sqft rate covering material and labour together, not itemized per good — confirmed by the Director ("client first negotiates material and then labour, so only one sqft rate including all + GST"), same model as turnkey, not a separate goods-pricing format; 5.1.9 is a Director-directed scope correction, the largest change since v5.0: the app is pre-sales quotation and lead-tracking only, not a billing or tax-compliance tool — confirmed against NestaPrime's own historical quotation (`23-A100-Quotation for Squash Court- Sanmati HS School.pdf`), which shows a flat 18% GST line and a GST-inclusive total, nothing else. Removed entirely: K.1a (194C/s.51 TDS logic), the cash-flow forecasting view, K.1b's per-item HSN/multi-state/separate-goods machinery, Appendix D.1's non-separable-category system, Part T's GST Liability report, and the corresponding Part O fields (`CLIENTS.is_tds_deductor` etc., `QUOTATIONS.gst_type`/`place_of_supply_state`/`registration_id_used`, `QUOTATION_LINES.gst_pct`/`hsn_sac`/`separate_goods_invoice`/`itc_eligible_for_client`). Replaced with: a single flat 18% GST line on the quotation subtotal, presented to the client as GST-inclusive (K.4, K.1b). Actual invoicing, HSN/SAC classification, place-of-supply, TDS and e-invoicing are confirmed to run entirely outside the app, in NestaPrime's existing Tally-based process; e-way bills remain correctly scoped to procurement (`PURCHASE_ORDERS.eway_bill_no`), unaffected. This substantially shrinks Gate 1's re-audit scope (R.0) and removes the CA-rounding-rule confirmation from Gate 2 entirely; 5.1.8 records the Director's decision to drop the mandatory `gst_opinion` CA-attachment requirement on the 5% separate-goods carve-out — superseded by this version, since that carve-out no longer exists; 5.1.7 adds Module 21 / Part T — Reporting & Extraction (Quotation Pipeline weekly, Margin Performance monthly, GST Liability quarterly), all built as snapshots of existing Part O tables with role gates matching K.3/M.7.2, no new source of truth; the CA-attachment requirement on the 5% separate-goods carve-out (K.4 safeguard) remains unchanged and open for a direct decision, not silently resolved by this version; 5.1.6 adds K.1b — GST mode is derived from Project Type, never a Sales-entered percentage; turnkey (New Build/Resurfacing/Repair) locks to SAC 9954/18% with no rate picker, Supply Only and separate-goods carve-outs resolve rate by item→HSN lookup only; also sets blended-to-client / category-internal pricing display and exclusive-by-default GST display for turnkey quotations (K.1b, M.6, Q.1); 5.1.5 adds the TDS rounding rule as a named Part R.0 sign-off item, closing the gap where `itds.rounding_rule` was introduced in 5.1.4 but had no explicit go-live checklist line; 5.1.4 adds `itds.rounding_rule` as a named Master Setting (Q.1) — the TDS rounding question raised in the re-audit addendum was previously unrecordable, held in the app as null/unconfirmed until the CA confirms in writing; 5.1.3 corrects GST-007: s.194C thresholds are alternatives not cumulative, adds the s.194C(5) FY-aggregate catch-up and FY scoping of `annual_paid_aggregate` (K.1a, K.4, Part O), and collapses the duplicated non-separable goods list into one canonical table at Appendix D.1; 5.0 third audit + final developer-readiness check applied; 5.1 adds Module 20 Communications — email/WhatsApp delivery of every document and vendor price-update requests: multi-state GST registrations, separate-goods safeguards, billing/IRN table, advance-GST and TDS-threshold cash-flow logic, ITC rules, work-package field, engineer-override workflow, skip-stage exception, evidence types, signatories table, Part S expanded**) |
| Date | September 2026 |
| Motto | "Less Information, Fast Result" |
| Prepared by | NestaPrime Leadership with AI assistance |

> **Notation.** All formulas use plain ASCII operators: `x` multiply, `/` divide, `-` subtract, so they survive copy-paste and text extraction. The `×` symbol is used only inside dimensions (e.g. 44 × 20 ft).

> **How to read this document.** Parts A–C say *why* and *who*, and the Module Map ties every module number to its section. Parts D–J are the engineering knowledge (sports, bases, structures, flooring, formulas). Parts K–M are the commercial and approval workflow. Part N is the schedule estimator, Part O the data model, Part P architecture and roadmap, Part Q Master Settings, Part R the sign-off checklist, Part S what NestaPrime must provide, Part T reporting extraction. Every number marked **[confirm]** is an initial default loaded into Master Settings (Part Q) and edited by NestaPrime at any time — nothing is hard-coded.

> **Units.** The app stores everything in SI internally (m, sqm, kg, cum) and converts for display; 1 sqm = 10.764 sqft. Every master rate carries its own unit. Formulas below are written in the unit stated in each line.

---

## PART A — VISION, PURPOSE & WHY

### A.1 The problem

| Pain point | Current reality | Cost to NestaPrime |
|---|---|---|
| Quotes take too long | 45–90 min per quote (Excel + vendor calls + formatting) | Lost deals to faster competitors |
| Pricing inconsistent | Same project quoted ₹12 L by one salesman, ₹15 L by another | Client distrust |
| Knowledge in heads | 2–3 seniors know rates; juniors depend on them | Cannot scale; key-person risk |
| Items forgotten | ~15% of projects miss something (drainage, shock pad, earthing) | Cost overruns, disputes |
| No profit visibility | Margin known only at project end | Under-quoting, loss-making jobs |
| No standardisation | 15 Excel files, no version control | Unprofessional image |
| No history | Last year's quote for a client is lost | Cannot reference or forecast |
| No approval discipline | Quotes go out before costs are checked | Commitments made on wrong numbers |

### A.2 The solution

**NestaPrime Estimator** (codename *NestaBuild*): an AI-assisted system that takes a project from **Cost Sheet → Estimate → Formal Quotation** in under 10 minutes of user time, with material consumption and procurement sheets generated automatically, every figure overridable with real vendor rates, and commercial secrets (cost price, margin, markup) never leaving the PM/Director view.

**Core philosophy:** the system fills 80% (standards, rates, formulas, documents); the user supplies 20% (site facts, client wishes, vendor quotes). Manual override at every stage. Nothing is skipped without PM or Director approval.

### A.3 Who uses it

| Role | What they do | What they see | Time saved |
|---|---|---|---|
| Sales Executive | Project setup, enters quantities and vendor quotes into the cost sheet, sends estimate and quotation to the client by email/WhatsApp from the app | Quantities, item rates, selling price, GST, total; **no** cost price, markup or margin (K.3) | 45 min → 5 min |
| Project Manager | Verifies cost sheet, manual vendor rates, material consumption, BOM, approves stage skips | All modules incl. cost price | 2 h → 15 min |
| Director / Owner | Margin governance, discount approvals, rate confirmation, profit analysis | Everything + dashboard | Manual → instant |
| Procurement Officer | Material consumption sheet, RFQ / PO / price-update requests to vendors by WhatsApp and email, proposes vendor rates on cost sheets | Quantities, item rates and line amounts; no labour, cost price, selling price or margin | 1 day → 1 h |
| Site Engineer | Site survey form, actuals entry | Survey, actuals, drawings | — |
| CA / Tax | *(v5.1.9: role retained for future use; the app currently has no per-quotation tax settings for CA to confirm — GST is a flat, Director-set rate, K.4)* | Read-only documents; no cost or margin | — |

### A.4 Success metrics

| Metric | Before | After | Target |
|---|---|---|---|
| Time to cost sheet | 45–90 min | 3–5 min | 90% faster |
| Time to formal quotation | 1–2 days | Same day | 80% faster |
| Estimate accuracy vs actual | ±25% | ±10% | 60% better |
| Forgotten items | 15% of projects | 0% | Eliminated |
| Cost overruns | 20% of projects | 5% | 75% reduction |
| Quotes sent without cost check | Unknown | 0% | Approval chain enforced |
| New salesperson ramp-up | 2–3 months | 2 hours | 95% faster |

---

## MODULE MAP (numbering used throughout this document)

| Module | Name | Defined in | Stage it feeds |
|---|---|---|---|
| 0 | Project Setup | Part B | Cost Sheet |
| 1 | Sport Selection | Part C | Cost Sheet |
| 2 | Flooring Selection | Part F.1–F.2 | Cost Sheet |
| 3 | Site Preparation & Establishment | Part D.4 | Cost Sheet |
| 4 | Base / Sub-base & Drainage | Part D.1–D.3 | Cost Sheet |
| 5 | Structure & Enclosure (Types A–G) | Part E | Cost Sheet |
| 6 | Flooring Surface (rolls, infill, line marking) | Part F.3–F.6 | Cost Sheet |
| 7 | Lighting | Part H | Cost Sheet |
| 8 | HVAC & Acoustics | Part G.5 | Cost Sheet |
| 9 | Sport Accessories | Part I | Cost Sheet |
| 10 | Additional Scope Checklist | Part I | Cost Sheet |
| 11 | Rate Sheet (AI / Manual, verification) | Part J.1–J.2 | Cost Sheet |
| 12 | Commercial Layer (cost → selling → GST) | Part K | Estimate, Quotation |
| 12A | Schedule Estimator | Part N | Quotation |
| 12B | Tender Mode | Part L | Quotation |
| 13 | Swimming Pool | Part G.1 | Cost Sheet |
| 14 | Gym | Part G.2 | Cost Sheet |
| 14A | Athletic Track & Play Equipment sub-modules | Part G.3–G.4 | Cost Sheet |
| 15 | Project Actuals | Part O (PROJECT_ACTUALS), Roadmap Phase 6 | Post-award |
| 16 | BOM & Procurement | Part J.4 | Procurement |
| 16A | Material Consumption Sheet | Part J.3 | Procurement |
| 17 | Exports (Cost Sheet, Consumption, RFQ, BOM, PDFs, Billing Handoff on Won) | Part J.4, M.6 | All stages |
| 18 | Document & Approval Workflow (Cost Sheet → Estimate → Quotation, attachments, skip-stage) | Part M | All stages |
| 19 | Master Settings & Overrides (all rates, %, floors editable by NestaPrime) | Part Q | All stages |
| 20 | Communications — email / WhatsApp delivery of every document; vendor price-update requests and reply capture | Part M.7 | All stages |
| 21 | Reporting & Extraction — Quotation Pipeline (weekly), Margin Performance (monthly); more cadences/reports added the same way | Part T | Post-award, Director dashboard |

---

## PART B — PROJECT SETUP (Screen 1, before sport selection)

### B.1 Setup fields

| # | Field | Options | Auto-effect |
|---|---|---|---|
| 1 | Project type | New Build (default) / Resurfacing / Repair / **Supply only** | Resurfacing hides Site Prep, Base, Structure; shows Flooring + Line Marking + Accessories. Supply only = goods delivered without installation: no labour, no site prep, GST at item HSN rates (K.4) |
| 2 | Client type | School / College / Housing Society / Corporate / Club / **Government (Tender)** / Individual | Default package, payment-term template, margin floor (K.2), warranty; Government switches on **Tender Mode** (Part L) |
| 3 | City / district | Mumbai / Delhi NCR / Bengaluru / Hyderabad / Chennai / Pune / Kolkata / Ahmedabad / Jaipur / Lucknow / Other (PM enters multipliers manually and they are logged; the monthly override report lists the most-used "Other" cities so the Director promotes them to the master table with fixed multipliers) | Regional multipliers, climate zone, rainfall zone, coastal flag, **wind zone (IS 875)**, **seismic zone (IS 1893)** |
| 4 | Distance from nearest NestaPrime hub | km (or PIN code) | Freight = trips x km x Rs/km, trips = ceil(total material tonnes / truck capacity) by vehicle class (Q.1); site-establishment uplift beyond 100 km |
| 5 | Site condition (topography) | Level / Sloped / Water-logged | Cut-fill, dewatering, drainage sizing |
| 6 | **Soil type** | Normal / Rocky / Black cotton / Sandy / Filled (loose) | Foundation depth, base type, rock-breaking, anti-termite |
| 7 | **Building status** (project default; asked again per sport in Module 1) | Existing building / New PEB building / Open air / Covered shed | Replaces fixed indoor/outdoor flag; drives structure, HVAC, drainage rules |
| 8 | Site access | Good / Narrow road (<4 m) / No crane access | Freight, crane hire, PEB flag, labour +15% |
| 9 | Power available | Yes / No / Partial | DG / solar / connection & load sanction added to scope |
| 10 | Water available | Yes / No | Borewell / tanker line (mandatory for pool, grass, hockey) |
| 11 | Number of courts | 1–N per sport | Multi-court layout, shared structure and poles |
| 12 | Unit system | Feet (default) / Metres | All I/O converts; sqft ↔ sqm |
| 13 | Package | Budget / Standard / Premium | Pre-selects flooring, structure, lighting, scope |
| 14 | Safe bearing capacity (SBC) | kN/sqm from soil report; blank until report | Foundation design input (E.5); mandatory where soil test is mandatory |
| 15 | Existing building clear height | ft (only when Building status = Existing) | Checked against the sport's minimum clear height (B.1a) |

### B.1a Building-status rule matrix (replaces every "indoor/outdoor" test in this document)

| Rule | Existing building | New PEB building | Covered shed (Type C) | Open air |
|---|---|---|---|---|
| Structure types allowed | none (fit-out only) | E | C (+ D / G) | A, B, D, F, G |
| Surface drainage (D.3) | no | perimeter only | yes | yes |
| Sub-surface drainage (turf) | no | no | yes | yes |
| HVAC (G.5) | optional | yes | no | no |
| Anti-termite (D.4) | yes (wooden floor) | yes | no | no |
| Lighting UF (H) | 0.7 | 0.7 | 0.6 | 0.6 |
| Lighting MF (H) | 0.8 | 0.8 | 0.7 | 0.7 |
| Gutter / downpipe | no | yes | yes | no |
| Roof for lights | ceiling / truss mount | truss mount | truss mount | poles |
| Min structure height | building height ≥ sport min | PEB height ≥ sport min | shed height ≥ sport min | — |

### B.2 Automatic triggers (examples)

| Selection | Effect |
|---|---|
| Client = School | Package Standard · Payment 40/40/20 · Margin floor 18% (see K.2) · Warranty 5 yr |
| Client = Government | Tender Mode ON · BOQ export · Retention 5–10% · Performance BG 3–5% · DLP 12 months · EMD tracked · packages hidden |
| City = Mumbai | Labour ×1.25 · Transport ×1.15 · Material ×1.10 · **Coastal = YES → hot-dip galvanise (+15% MS)** · Rainfall High · Wind zone 3 · Seismic zone III · Climate Hot-humid (HVAC 1.3) |
| City = Chennai | Coastal YES · Wind zone 5 (cyclonic) → pipe upsize + cross-bracing · Seismic III |
| City = Delhi NCR | Wind zone 4 (47 m/s) → section upsize · Seismic zone IV → foundation upsize · Climate Hot-dry → HVAC factor 1.2 |
| Soil = Rocky | Rock-breaking line · foundation depth same, rock-anchor bolts · Base RCC direct |
| Soil = Black cotton | Foundation +2 ft or under-reamed piles · sand-filling layer 6″ · CNS layer |
| Site = Water-logged | Dewatering · drainage upsized · base WBM thicker |
| Access = No crane | PEB flagged "requires crane — discuss" · labour +15% |
| Power = No | Scope auto-checks DG / Solar / Connection |
| Distance > 100 km | Site establishment +2% · labour accommodation line |

---

## PART C — MASTER SPORT LIST (Module 1, 30 sports)

All dimensions in **feet** unless stated. *Playing* = lines only; *Build* = playing + run-off on **both** sides: `build_L = playing_L + 2 x run_off_L`, `build_W = playing_W + 2 x run_off_W`. The Build column below is the total L × W the app prices; "+ x ft" means x ft on **each** side.

### C.1 Indoor-primary sports

| # | Sport | Playing | Build (incl. run-off) | Min clear height | Body | Best flooring |
|---|---|---|---|---|---|---|
| 1 | Badminton | 44 × 20 | 52 × 30 club / 60 × 36 tournament | 24 ft club / 30 ft intl | BWF | Wooden sprung 22 mm + PVC mat |
| 2 | Table Tennis | 9 × 5 (table) | 40 × 20 per table club / 46 × 23 per table tournament (14 × 7 m) | 12 ft (16 ft intl) | ITTF | Hardwood 22 mm / PVC 4.5 mm |
| 3 | Squash | 32 × 21 | 32 × 21 + walls | 18.5 ft | WSF | Hardwood 22 mm + plaster walls |
| 4 | Basketball | 92 × 49 | 105 × 62 | 23 ft | FIBA | Wooden maple 22 mm / PU 6 mm |
| 5 | Volleyball | 59 × 29.5 | 79 × 49 | 23 ft (41 intl) | FIVB | PU 6 mm |
| 6 | Gymnasium / multi-purpose hall | custom | per layout | 16 ft | NestaPrime standard (no federation) | Rubber 8 mm / wooden |
| 7 | Shooting range 10 m | 33 × (3.3 per lane) | 44 × (3.3 per lane + 3 each side) — firing point 5 ft + rear 6 ft | 12 ft | ISSF | Concrete + rubber |
| 8 | Kabaddi | 43 × 33 | 56 × 46 | 16 ft | IKF | PU 6 mm / mat |
| 9 | Wrestling / boxing / martial arts | mat 40 × 40 | 50 × 50 | 16 ft | UWW / IBA | Rubber 15–20 mm / PU mat |
| 10 | Indoor cricket nets | 80 × 12 per lane | 86 × (12 per lane + 3 between lanes) | 16 ft | NestaPrime standard (BCCI practice-net guidance) | Turf 30 mm |

### C.2 Outdoor-primary sports

| # | Sport | Playing | Build (incl. run-off) | Body | Best flooring |
|---|---|---|---|---|---|
| 11 | Box cricket | 50 × 25 (custom common) | 56 × 31 (3 ft buffer each side, inside the net) | NestaPrime standard (no federation) | Cricket turf 40–50 mm |
| 12 | Cricket practice nets | 80 × 12 per lane | 86 × (12 per lane + 3 between lanes) | NestaPrime standard (BCCI practice-net guidance) | Turf 30 mm |
| 13 | Football 11-a-side | 344 × 223 (105 × 68 m) | 360 × 240 | FIFA | FIFA Quality Pro 50 mm |
| 14 | Football 7-a-side | 197 × 130 | 210 × 145 | FIFA | Turf 40 mm |
| 15 | Football 5-a-side / futsal | 130 × 65 | 145 × 80 | FIFA | Turf 40 mm / acrylic |
| 16 | Tennis (hard / clay / grass) | 78 × 36 | 120 × 60 | ITF | Acrylic 3–5 mm / clay / grass |
| 17 | Padel | 66 × 33 (20 × 10 m) | 66 × 33 court + 6 ft access strip on the door side (not an FIP requirement; NestaPrime standard) | FIP | Monofilament turf 12 mm + sand |
| 18 | Pickleball | 44 × 20 | 60 × 30 (64 × 34 tournament) | USA Pickleball | Acrylic 3 mm |
| 19 | Basketball outdoor | 92 × 49 | 105 × 62 | FIBA | Acrylic 3 mm / PU 5 mm |
| 20 | Volleyball outdoor | 59 × 29.5 | 79 × 49 | FIVB | PU 5 mm / sand |
| 21 | Beach volleyball | 52 × 26 | 72 × 46 club / 92 × 66 competition, sand 16 in | FIVB | Washed silica sand |
| 22 | Hockey turf | 300 × 180 | 330 × 200 FIH (15 ft ends, 10 ft sides) / 320 × 200 school | FIH | FIH certified: water-based 12–15 mm / sand-dressed 20–25 mm |
| 23 | Athletic track 400 m, 8 lane | 400 m oval | ~580 × 300 | World Athletics | Synthetic 13 mm |
| 24 | Athletic track 200/250 m (school) | oval | per layout | World Athletics (scaled, non-certified) | Synthetic 13 mm |
| 25 | Skating rink | 100 × 60 | 110 × 70 + barrier | World Skate | Concrete + coating |
| 26 | Archery range | distance input 18 m indoor / 30–90 m outdoor × 10 per lane | distance + 30 ft overshoot zone, lanes + 10 ft each side | World Archery | Grass / rubber |
| 27 | Kids play area | equipment footprint | footprint + 6 ft fall zone each side | ASTM F1487 / IS 15650 | EPDM system 40 mm / rubber tiles |
| 28 | Swimming pool 25 m | 82 × 41 (6 lane) | 102 × 61 (deck 10 ft each side) | World Aquatics | Anti-slip tiles / mosaic |
| 29 | Swimming pool 50 m | 164 × 82 (8–10 lane) | 194 × 112 (deck 15 ft each side) | World Aquatics | Anti-slip tiles |
| 30 | Multipurpose court | 120 × 80 | per sports chosen | Per sport marked (FIBA / FIVB / BWF / USA Pickleball) | Acrylic 3 mm / PU 5 mm |

**Additional flooring option (any field sport):** Natural grass (sod/seed) with sprinkler irrigation and water tank — see F.4.

### C.3 Sport record fields
`id, name, icon, default_building_status, playing_L/W/H, build_L/W/H, run_off_L/W, governing_body, standard_name, standard_level, source_citation, aspect_ratio, deviation_thresholds{amber 2–10%, red >10% or below minimum}, valid_flooring_ids[], valid_structure_types[], valid_fence_types[], lighting{practice_lux, match_lux, tournament_lux, pole_count_default, pole_height}, accessories[], mandatory_scope_items[], line_marking_sets[], warranty_default`

Source citation is printed on the client PDF (e.g. "BWF Statutes Sec 1.1, 2024").

---

## PART D — BASE / SUB-BASE

### D.1 Base types

| Type | Composition | Thickness | Best for | Cost ₹/sqft [confirm] | Not for |
|---|---|---|---|---|---|
| WBM | Crushed stone + binding | 6–10″ | Outdoor courts, turf, roads | 45–65 | Indoor, heavy water-logging |
| Asphalt | Aggregate + bitumen over WBM | 3–4″ | Tennis hard, basketball, track | 80–120 | Indoor (fumes), turf |
| PCC (M15–M20) | Cement + sand + aggregate | 4–6″ | Indoor courts, light outdoor | 55–75 | Heavy loads, ground movement |
| RCC (M20–M25) | PCC + steel | 6–12″ | Footings, pool, gym, Padel | 85–120 | Budget projects |

*Note: the Rs/sqft figures above are all-in sanity ranges (material + labour) used only to flag a take-off outside the expected band; the Cost Sheet prices base work from quantities (cum, kg) x material rates + labour activity rates (E.2, J.2, J.3), never from these lump sums.*

### D.2 Base selection matrix

| Sport | Building status | Soil | Recommended | Alternative | Why |
|---|---|---|---|---|---|
| Badminton / TT / squash / gym | Existing or PEB | Any | PCC 4–6″ | RCC 6″ | Smooth for wooden/PU |
| Box cricket / football turf | Open / covered | Normal | WBM 8–10″ (+ PCC 4″ box) | — | Drainage for turf life |
| Box cricket / football turf | Open | Rocky | RCC 6″ direct | — | Rock breaking costly |
| Box cricket / football turf | Open | Black cotton | Sand layer 6″ + WBM 10″ + geotextile | RCC 6″ | Swelling soil |
| Tennis / basketball / pickleball hard | Open | Normal | WBM 6″ + Asphalt 3″ | PCC 6″ | Bounce consistency |
| Tennis clay | Open | Normal | WBM 8″ + gravel | — | Drainage layer |
| Athletic track | Open | Normal | WBM 8″ + Asphalt 2″ | RCC + asphalt | Even surface |
| Padel | Open / covered | Normal | RCC 6″ over WBM 6″ + perimeter beam | — | Glass post anchoring |
| Swimming pool | Any | Any | RCC 8–12″ shell | — | Water load |
| Kids play | Open | Normal | WBM 6″ | PCC 4″ | Impact base |
| Beach volleyball | Open | Any | Drainage layer + geotextile + 16″ sand | — | Sand drainage |

### D.3 Drainage calculation (Module 4, mandatory outdoor)
- Perimeter drain length = build perimeter (ft); 9″ × 9″ (normal) / 12″ × 12″ (high rainfall) RCC/brick channel with grating
- Sizing by the rational method: run-off Q (litres/s) = 1000 x 0.278 x C x i x A, with C = 0.9 (turf/acrylic on WBM), 0.6 (natural grass), i = city design rainfall intensity mm/h (Master Settings, e.g. Mumbai 75, Delhi 50, Chennai 70 [confirm]), A in sq km — the app stores area in sqm, so `A_sqkm = build_area_sqm / 1,000,000` (a 116 sqm box cricket = 0.000116 sq km → Q ≈ 2.2 l/s at C 0.9, i 75); if Q < 1 l/s a perimeter drain alone suffices, otherwise pipe size from the capacity table (100 mm up to 8 l/s, 150 mm up to 20 l/s, 225 mm up to 50 l/s at 1:100 slope)
- Sub-surface pipe spacing by soil permeability: sandy 8 m, normal 5 m, clay/black cotton 3 m c/c
- Catch pits: 1 per 50 ft of drain; soak pit or outfall connection at end; rainwater harvesting pit sized to 10% of annual run-off where the scope item is ticked
- Sub-surface (turf): perforated 100 mm pipes at the soil-based spacing below (5 m normal) + gravel 4–6″; slope 1:100 minimum, 1:80 high rainfall
- Outputs: drain running ft, pits count, pipe m, gravel cum

### D.4 Site preparation & establishment (Module 3)
- Cut/fill volume from slope %, levelling, roller compaction
- Rock breaking (rocky), dewatering (water-logged), sand/CNS layer (black cotton)
- Debris removal, anti-termite (indoor), soil test with SBC report (mandatory for PEB, pool, black-cotton, rocky, filled and water-logged sites; 1 per site; result feeds foundation design per E.5 rule)
- **Site establishment [confirm 4–8%]:** mobilisation/demobilisation, temporary power & water, labour hutment, site engineer days, scaffolding, safety gear

---

## PART E — STRUCTURES & ENCLOSURES (Module 5, Types A–G)

### E.1 Structure types

| Type | Description | MS section | Wall thk | Column spacing | Foundation | Height | Cost ₹ [confirm] (unit as stated) |
|---|---|---|---|---|---|---|---|
| **A** Open-end net (3 sides + roof) | 3 sides + roof netted, one end open | 3″×3″ (4″×4″ windy/coastal) | 2.0–2.5 mm | 10 ft | 3 ft, 1.5×1.5 ft, M25 | 12–16 ft | 180–250 /sqft covered |
| **B** Fully closed 4-side + roof + gate | All sides netted, gated | 4″×4″ (5″×5″ heavy/seismic) | 2.5–3.0 mm | 8–10 ft | 4 ft, 2×2 ft, M25 | 14–20 ft | 220–320 /sqft covered |
| **C** Roof shed only | Truss + GI/polycarbonate/shade net | 3″×3″ / 4″×4″ truss (tall variant 4″×4″ + 5″×5″ columns) | 2.5 mm | 10–12 ft | 2.5 ft (3.5 ft tall) | 10–14 ft (tall variant 20–26 ft) | 120–180 /sqft roof area (tall 180–260) |
| **D** Four-side cover, no roof | Side netting only | 2.5″×2.5″ – 3″×3″ | 2.0 mm | 10 ft | 2 ft | 10–16 ft | 100–180 /sqft net area |
| **E** PEB shed | Factory steel building, walls, insulated roof | PEB engineered | — | 20–30 ft bays | RCC pedestal + anchor bolts | 16–30 ft | 350–550 /sqft built-up |
| **F** Padel court | 12 mm tempered glass 3 m + mesh 1 m, galvanised 100×50 posts | 100×50 RHS | 3.0 mm | per panel 2 m | RCC slab 6″ + perimeter beam | 13 ft | 450–650 /sqft court |
| **G** Chain-link fence (new) | GI / PVC-coated chain-link 50×50 mm, 10–12 ft, 2.5″ posts @ 10 ft, gate | 2.5″ GI | 2.0 mm | 10 ft | 2 ft | 10–12 ft | 60–110 /running ft |

### E.2 Pipe weight table (kg/m) — square hollow sections, IS 4923 [confirm with supplier]

| Section | 2.0 mm | 2.5 mm | 3.0 mm | 4.0 mm |
|---|---|---|---|---|
| 2.5″×2.5″ (63×63) | 3.8 | 4.7 | 5.6 | 7.3 |
| 3″×3″ (75×75) | 4.6 | 5.7 | 6.8 | 8.9 |
| 4″×4″ (100×100) | 6.1 | 7.6 | 9.1 | 12.0 |
| 5″×5″ (125×125) | 7.7 | 9.6 | 11.5 | 15.1 |
| 6″×6″ (150×150) | 9.3 | 11.6 | 13.8 | 18.2 |
| RHS 80×40 | 3.6 | 4.5 | 5.3 | 6.9 |
| RHS 100×50 (Padel) | 4.6 | 5.7 | 6.8 | 8.9 |
| Round 2″ NB (IS 1239 medium) | 3.6 kg/m | | | |
| Round 2.5″ NB (fence posts) | 5.1 kg/m | | | |
| Round 3″ NB | 6.4 kg/m | | | |

Wind-zone upsize (E.5) steps to the next **column** for wall thickness (e.g. 3.0 → 4.0 mm) and the next **row** for section (e.g. 5″ → 6″).

**Canonical costing path (one path only):** the Cost Sheet prices structures from a **quantity take-off** — steel kg x Rs/kg, netting sqm x Rs/sqm, concrete cum x Rs/cum, paint/galvanising per kg — plus MS labour from J.2 — Rs/kg fabrication and Rs/kg erection activity rates x kg where rate cards exist, else the J.2 category % — which **covers fabrication, welding and erection**. The Rs/sqft ranges in E.1 and E.4 are **all-in sanity checks** (material + labour) used only to flag a take-off that lands outside the range; they are never added to a take-off, and labour % is never added on top of them.

Steel material cost = total length (m) x kg/m x Rs/kg x (1 + wastage 5%) + consumables (electrodes 2% of steel cost) + primer/paint (Rs/kg) or hot-dip galvanising (Rs/kg). Labour (fabrication + erection) = J.2 activity rates x kg, or the J.2 % of material cost as fallback.

### E.2a Take-off rules per structure type (L, W = build dimensions; H = structure height; S = column spacing; D = foundation depth)

| Item | Type A | Type B | Type C | Type D | Type G fence |
|---|---|---|---|---|---|
| Columns | `2 x (ceil(L/S)+1) + ceil(W/S) - 1` (open end has none) | `2 x (ceil(L/S)+1) + 2 x (ceil(W/S) - 1)` | as B | as B | posts `ceil(perimeter/S)` |
| Column length | `H + D` each | `H + D` | `H + D` | `H + D` | `H + D` |
| Top / tie beams | perimeter minus open end | perimeter | perimeter | perimeter | top rail + mid rail = 2 x perimeter |
| Roof trusses | `ceil(L/S) + 1` trusses x W | as A | as A | — | — |
| Purlins | `ceil(W_m / 1.2) x L_m` (metres) | as A | as A | — | — |
| Cross bracing | 2 per corner bay if wind zone ≥ 4 | as A | as A | as A | — |
| Netting area | `(2L + W) x H + L x W` | `2(L + W) x H + L x W` | roof sheet `L x W x 1.1` | `2(L + W) x H` | chain-link `perimeter x H` |
| Foundations | one per column, `1.5 x 1.5 x D` ft | `2 x 2 x D` ft | `1.5 x 1.5 x D` ft (tall variant `2 x 2 x D`) | `1 x 1 x D` ft | `0.75 x 0.75 x D` ft |
| Gate | 1 | 1 gate + net door | — | 1 | 1 |
| Shared edge (multi-court) | deduct `ceil(L/S)+1` columns and one beam per shared edge | | | | |

Type E (PEB) is priced from the PEB vendor's Rs/sqft built-up quote (Manual rate) plus foundations by take-off. Type F (Padel) is priced per court from the glass/steel kit vendor quote plus base take-off.

### E.3 Netting grades

| Grade | Material | Twine | Mesh | UV | Use | ₹/sqm [confirm] |
|---|---|---|---|---|---|---|
| N1 Budget | Nylon | 1.5 mm | 50 mm | No | Practice nets | 25–35 |
| N2 Standard | HDPE | 2.0 mm | 45 mm | Yes | Box cricket, football | 40–55 |
| N3 Heavy | HDPE | 3.0 mm | 40 mm | Yes | Premium, coastal, roof | 65–90 |
| N4 Welded mesh | GI 4 mm | — | 50×50 | — | Padel above glass | 350–450 |

### E.4 Structure selection matrix

Cost sanity ranges are those of the referenced type in E.1 (not repeated here). **Rule: structure height must be ≥ the sport's minimum clear height (Part C); the app blocks a selection that violates it.**

| Sport | Structure | Section | Height | Why |
|---|---|---|---|---|
| Box cricket budget | A | 3″×3″ | 12 ft | Cost-effective |
| Box cricket premium | B | 4″×4″ | 14 ft | Full containment |
| Football 5-a-side | A | 4″×4″ | 16 ft | Larger span |
| Football 7-a-side | B | 4″×4″ | 18 ft | Ball trajectory |
| Badminton covered | C (tall variant, 4″×4″ truss) + D | 4″×4″ | 24 ft minimum | Type C standard 10–14 ft is below the badminton minimum; use tall C or Type E |
| Badminton / basketball / TT new hall | E PEB | PEB | 24–30 ft | Permanent |
| Tennis / pickleball / basketball outdoor | G fence | 2.5″ GI round | 10–12 ft | Ball containment |
| Padel | F | 100×50 RHS | 13 ft | Glass wall |
| Kids play / archery | D | 2.5″ / 3″ | 10–12 ft | Safety |
| Pool boundary | G fence | 2.5″ GI round | 4–6 ft | Mandatory safety |

### E.5 Auto-enhancements

| Condition | Effect |
|---|---|
| Coastal | Hot-dip galvanise; +15% MS |
| Wind zone 4–5 | Section to next E.2 row; wall thickness to next E.2 column; cross-bracing |
| Seismic IV–V | Foundation +0.5 ft depth & width |
| High rainfall | Gutter + downpipe; roof slope ≥ 1:12 |
| Height > 20 ft or PEB | Crane hire line |
| Multi-court | Shared columns; shared poles |

Codes referenced: IS 456 (concrete), IS 800 (steel), IS 875 Pt 3 (wind), IS 1893 (seismic), IS 4923 (SHS), IS 15650 (play equipment), NBC 2016.

**Structural responsibility rule.** The app is an *estimating* tool: it produces quantities and costs from the standard configurations above, which are NestaPrime's proven designs for normal conditions. It does not design structures. A licensed structural engineer's design and sign-off (member sizes, bracing, foundation from the site's safe bearing capacity) is **mandatory and auto-added as a scope line** when any of these apply: height > 16 ft; span > 30 ft; wind zone ≥ 4; seismic zone ≥ IV; coastal; black-cotton, filled or water-logged soil; PEB (Type E); pool; Padel (glass loads); or Government/Tender client. Foundation depths in E.1 are starting defaults; the engineer's design overrides them and the Cost Sheet is revised. **Engineer-override workflow:** (1) the engineer's design is uploaded with tag `structural_design`; (2) the system auto-creates CS-R(n+1) in Draft; (3) PM updates member and foundation lines from the design; (4) PM re-verifies; (5) linked Estimates/Quotations are flagged "rebase required" (M.2 rule 4); (6) Sales is notified. If the design arrives after the Estimate was Sent, the Estimate gets a major revision before anything further goes to the client. The auto-added scope line "Structural engineer design & sign-off" carries a priced default from Master Settings [confirm: Rs 15,000 simple net structure · Rs 35,000 PEB / Padel / pool · Rs 50,000+ multi-court or government], so the Cost Sheet never carries it at zero. Soil test (SBC) is mandatory for PEB, pool, and for black-cotton, rocky, filled and water-logged sites; the SBC value is a Project Setup field.

---

## PART F — FLOORING (Modules 2 and 6)

### F.1 Indoor flooring guide

| Sport | Primary | Secondary | Budget | Why |
|---|---|---|---|---|
| Badminton | Wooden sprung 22 mm + BWF-approved PVC mat 4.5–7 mm | PU 6 mm | PVC mat 4.5 mm on PCC | BWF tournaments are played on approved PVC mats laid over a wooden or synthetic base; bare wood is a club finish |
| Table tennis | Hardwood 22 mm or ITTF-approved PVC/PU 4.5–6 mm | PU 6 mm | Vinyl 4 mm | ITTF approves wood and synthetic; non-reflective, non-slip |
| Squash | Hardwood strip 22 mm (maple/beech) on sprung battens | — | — | WSF specifies unsealed hardwood floor |
| Basketball | Maple 22 mm | PU 6 mm | Vinyl 4 mm | Tournament standard |
| Volleyball | PU 6 mm | Teak 22 mm | Vinyl 4 mm | Shock absorption |
| Gym | Rubber 8 mm (cardio) / 15–20 mm (free weights) | Wooden | Vinyl | Equipment drops |
| Kabaddi | PU 6 mm / mat | Wooden | Vinyl | Barefoot grip |
| Wrestling / boxing | Rubber 15–20 mm + mat | PU mat | — | Falls |
| Indoor nets | Turf 30 mm | Rubber mat | — | Ball behaviour |

### F.2 Outdoor flooring guide

| Sport | Primary | Secondary | Budget | Why |
|---|---|---|---|---|
| Football 11 | FIFA Quality Pro 50–60 mm | FIFA Quality 50 mm | Multi-sport 40 mm | Certification |
| Football 5/7 | Multi-sport 40 mm | Cricket 40 mm | Poly 30 mm | Cost/performance |
| Box cricket | Cricket turf 40 mm | Multi-sport 40 mm | Poly 35 mm | Bounce |
| Practice nets | Cricket 30 mm | Multi 30 mm | Poly 25 mm | Bowling |
| Tennis hard | Acrylic 3–5 mm (5–8 coats) | Synthetic 5 mm | Concrete + paint | ITF |
| Tennis clay | Red clay 4–8″ | — | — | Traditional |
| Tennis grass | Bermuda | Rye | — | Premium |
| Padel | Monofilament 12 mm + sand | — | — | FIP |
| Pickleball | Acrylic 3 mm | Concrete + coating | — | USA Pickleball |
| Basketball outdoor | Acrylic 3 mm | PU 5 mm | Concrete + coating | Weather |
| Volleyball outdoor | PU 5 mm | Sand | Concrete | All-weather |
| Beach volleyball | Washed silica sand 16″ | — | — | FIVB |
| Hockey | FIH water-based 12–15 mm (needs irrigation) | FIH sand-dressed 20–25 mm | Multi-sport 40 mm (non-FIH, school use) | FIH pitches are short-pile; 50 mm turf is football turf and is not hockey-legal |
| Track | Sandwich system 13 mm | Full-PU 13 mm | Spray-coat 13 mm (non-certified) | World Athletics certified systems; spike-resistant |
| Skating | Concrete + coating | Tiles | — | Smooth |
| Kids play | EPDM system 40 mm (10 mm EPDM wearing + 30 mm SBR base; CFH 1.5 m) | Rubber tiles 25–40 mm | Grass / sand | Fall protection — 15 mm EPDM alone gives CFH under 1 m |
| Pool | Anti-slip tiles | Mosaic | Marble | Non-slip |
| Multipurpose | Acrylic 3 mm | PU 5 mm | Concrete | Multi-line |

### F.3 Layer systems
- **Indoor wooden (top to bottom):** hardwood 22 mm T&G → 12 mm ply → battens/cradles with rubber pads (the sprung layer) → moisture barrier (DPM) → PCC 4–6″ / RCC 6″ → compacted stone → subgrade
- **Outdoor turf (top to bottom):** turf 30–60 mm with infill per the F.5 pile-height table → shock pad 8–10 mm (opt.) → stone-dust levelling 2″ → WBM 8–10″ (or PCC 4″ for box cricket) → geotextile → perforated drainage pipes in gravel trenches at 5 m c/c in the subgrade (D.3) → compacted subgrade
- **Outdoor hard:** acrylic 3–6 mm → asphalt 3″ over WBM 6″ *or* PCC 6″ → WBM/compacted stone + geotextile
- **Padel:** turf 12 mm + sand → RCC 6″ over WBM 6″ → perimeter beam → glass + mesh + galvanised frame

### F.4 Natural grass & irrigation (new)
Topsoil 6″ + sand amendment → sod (or seed, 6–8 wks) → pop-up sprinklers grid 12 m → pump + 10,000 L tank → monthly maintenance note. Hockey water-based turf: sprinkler cannons ×6 + 50,000 L tank + pump.

### F.5 Turf roll & infill calculation
- Rolls 4 m (or 2 m) wide x 25 m long. The app evaluates **both lay directions x every available roll width x cut-length allowed yes/no** and picks the minimum ordered sqm. For one option: strips = ceil(span_across / roll_width); rolls_per_strip = ceil(span_along / roll_length) (or exact cut length if allowed); ordered_sqm = strips x rolls_per_strip x roll_width x roll_length (or x cut length); wastage % = (ordered_sqm - build_area_sqm) / build_area_sqm. Pile direction must be the same for all strips (noted on the consumption sheet). Example: 50 × 25 ft box cricket = 15.2 x 7.6 m → strips = ceil(7.6/4) = 2, rolls per strip = ceil(15.2/25) = 1, ordered = 2 x 1 x 4 x 25 = 200 sqm vs 116 sqm needed — 72% waste, so the app must also offer cut-length ordering (supplier cuts 2 rolls x 15.2 m = 122 sqm, 5% waste). Rule: order by cut length when the supplier allows; whole rolls otherwise.
- Infill kg = area_sqm x (sand + rubber) by pile height [confirm]: 30 mm — sand 12, rubber 4 · 40 mm — sand 18, rubber 7 · 50 mm FIFA Quality — sand 22, rubber 9 · 50–60 mm FIFA Quality Pro — sand 25–30, rubber 8–12 · padel 12 mm — sand 8, no rubber; line marking: inlaid (turf) per set, painted (acrylic) per set

### F.6 Line-marking sets

| Court | Sets allowed | Colour | ₹/set [confirm] |
|---|---|---|---|
| Multipurpose | up to 4 (basketball white, volleyball yellow, badminton green, pickleball blue) | per sport | 8,000–15,000 |
| Turf | inlaid white/yellow | per sport | 12,000–25,000 |

---

## PART G — SPECIALTY MODULES

### G.1 Swimming pool (Module 13)

| Block | Inputs | Calculates |
|---|---|---|
| Shell | L × W × depth profile; RCC / FRP liner; indoor / outdoor | Excavation, RCC M25 + waterproofing admixture, steel, PCC, plaster, tiles, coping |
| Filtration | Volume (auto) | Turnover 4–6 h → pump kW, sand filter size, plant room, pipework, skimmers / overflow gutter, balancing tank |
| Treatment | Chlorine / salt / UV / ozone | Dosing, test kit |
| Deck & safety | Deck width | Anti-slip tiles, channel drain, ladders, lane ropes, blocks, lifeguard chair, **fence Type G mandatory**, depth markers |
| Water | Fill volume | Source (borewell/tanker), make-up water |
| Options | Heating (heat pump), cover, underwater lights, **indoor: PEB cover + dehumidification** | Line items |
| Compliance | — | Pool safety NOC, lifeguard note, drowning-prevention signage |

### G.2 Gym (Module 14)

| Block | Inputs | Calculates |
|---|---|---|
| Area | sqft, zones (cardio / strength / free weights / functional / studio) | Flooring per zone |
| Equipment | Package × capacity (users/hour) | Equipment list (brand tier, qty, rate) from catalogue |
| Services | — | HVAC, mirrors, 300 lux, electrical points per machine, sound, reception, lockers, showers |

### G.3 Athletic track sub-module
Lanes (4/6/8) × 1.22 m → track width; kerb length; D-zone area; field events checklist (long/triple jump pit, shot put circle, discus cage, high jump); drainage ring.

### G.4 Kids play equipment catalogue
Multi-play unit, swings, slides, see-saw, climbers, spring riders — each with fall-zone → EPDM area auto-calc, IS 15650 compliance note.

### G.5 HVAC & acoustics (Module 8, indoor)
- Tonnage (TR) = (floor area sqft / 130) x climate factor x height factor [confirm]. Climate: Hot-humid 1.3 · Hot-dry 1.2 · Moderate 1.0 · Cold 0.8. Height: ≤ 16 ft 1.0 · > 16 to ≤ 24 ft 1.2 · > 24 ft 1.4. Plain-text: `tonnage = (area_sqft / 130) * climate_factor * height_factor`. Example: 60 × 36 × 24 ft badminton hall in Mumbai = (2,160 / 130) x 1.3 x 1.2 = **25.9 TR, round to 26 TR** (a volume-per-1,000-cu-ft rule, used in earlier drafts, over-states large halls 3–4x and must not be used). Ducting priced Rs/sqft of floor; fresh air 15 CFM/person; HVAC engineer to confirm above 40 TR
- Acoustic panel area = wall_area x coverage %, where `wall_area = 2 x (L + W) x H` (squash 40%, badminton 25%, TT 25%, gym 20%)

---

## PART H — LIGHTING (Module 7)

**Fixtures = (Build area sqm x Lux) / (Lumens per fixture x UF x MF)**, UF 0.6 outdoor / 0.7 indoor; MF 0.8 indoor, 0.7 outdoor (dust, IS 3646 / IS 1944). Uniformity target U0 ≥ 0.5 club / 0.7 tournament and glare rating GR < 50 are stated on the client PDF as design intent; the lighting vendor's photometric layout confirms them for tournament-level jobs.

Plain-text form for developers: `fixtures = ceil((area_sqm * lux) / (lumens_per_fixture * UF * MF))`. Example: 50 × 25 ft box cricket = 116 sqm x 500 lux = 58,000 lm / (26,000 lm x UF 0.6 x MF 0.7 = 10,920) = 5.3, rounded up to **6 fixtures**.

| Lux level | Practice | Match | Tournament |
|---|---|---|---|
| Court sports | 200 | 500 | 750 |
| Football / cricket | 200 | 500 | 750–1000 |
| Pool | 300 | 500 | — |
| Gym | 300 | — | — |

**Fixture master:** W, lm (e.g. 200 W = 26,000 lm at 130 lm/W), beam angle, IP66, rate. **Mounting mode** follows the structure (B.1a): Types A/B/C/E → fixtures on columns or trusses, no poles; open air / Type D / Type G → poles. **Pole table (open-air only):** box cricket nets-only 4, football 7-a-side 6–8, tennis 4–8, basketball 4, padel 4, pool 6; pole height 8/10/12 m. Final fixture count = max(formula result, poles x 1) and rounded to an even number when poles are used, so every pole carries at least one fixture. Add: cabling by distance, MCB panel, earthing, lightning arrestor (>10 m), total kW, monthly running cost at city tariff, solar offset option.

---

## PART I — ACCESSORIES & ADDITIONAL SCOPE (Modules 9–10)

**Accessories (auto per sport):** goals, nets, posts, scoreboards, stumps, umpire chairs, lane ropes, starting blocks, glass doors (padel), padel nets, pickleball nets, archery targets.

**Scope checklist groups (unchecked = excluded and listed under Exclusions):**
- Civil: changing rooms, toilets, storage, first-aid, security cabin, cafeteria/kiosk, pavilion/gallery + seating count, walkways, boundary wall
- Electrical: connection & load sanction, DG, solar, CCTV, PA, Wi-Fi, scoreboards
- Water: borewell, municipal connection, rainwater harvesting, irrigation, tank
- External: parking, landscaping, signage, main gate
- Services: design & structural drawings, soil test, NOCs, PEB design fee
- Maintenance: AMC (turf brushing, infill top-up, acrylic re-coat 5–7 yr)

---

## PART J — RATES & MATERIAL CONSUMPTION

### J.1 Rate sheet (Module 11)
- Every item: **AI / Manual** toggle. AI shows "Last confirmed ₹X · Vendor Y · dd-mm-yyyy"
- Manual entry → "Save as rate?" → saved as **Unverified** (grey). PM or Director confirms → becomes AI rate. Unverified rates never become defaults.
- Stale flag after 90 days; Director quarterly review list
- **Commodity alert:** Director can set an index watch (steel Rs/kg, turf Rs/sqm); a ±10% move against the master rate flags every open Cost Sheet using it and suggests a bulk update (Q.2 rule 5)
- Estimates freeze rates used; later changes never alter old documents
- Regional multipliers apply to **AI/master rates only**. A Manual rate carries `city_of_quote` and is used as entered (it is already local). The labour multiplier applies to the labour Rs amount, not to the labour %.
- Every master item carries `labour_category_id` (J.2); the blended 22% is used only when an item has none.
- Bulk actions (all AI / all Manual / category)
- Every item carries `hsn_sac` code

### J.2 Labour — activity rate cards first, % as fallback [confirm]

Preferred: **activity-based labour rates** in Master Settings — Rs/sqft turf laying, Rs/kg MS fabrication, Rs/kg erection, Rs/sqft wooden floor, Rs/sqft acrylic (per coat), Rs/cum concrete, Rs/point electrical — so labour follows effort, not material value (imported flooring no longer inflates labour). Where no activity rate exists the category % below applies to that category's material cost — and the Cost Sheet shows a warning line "Activity rate missing for [category] — using fallback X%". If more than 3 categories on a Cost Sheet lack activity rates, PM verification requires Director confirmation; the go-live checklist (Part R) requires activity rates for all eight categories before Phase 1b.

| Category | Default |
|---|---|
| Civil / base / site prep | 30% |
| MS fabrication & erection | 22% |
| Turf laying | 12% |
| Wooden flooring | 16% |
| Acrylic / PU | 20% |
| Electrical | 25% |
| Netting | 15% |
| Pool MEP | 25% |
| Blended fallback | 22% |

### J.3 Material Consumption Sheet (new, Module 16A)
Auto-generated from all modules — the procurement working document. Editable Excel export.

| Column | Example |
|---|---|
| Category | MS structure |
| Item & spec | SHS 3″×3″ × 2.5 mm, IS 4923 |
| Unit | kg |
| Theoretical qty | 3,420 |
| Wastage % | 5 |
| Order qty | 3,591 |
| Rate (internal only) | 68 |
| Amount (internal only) | 2,44,188 |
| Vendor | — |
| Delivery date | — |
| Received qty / Balance | — |
| Remarks | Galvanised, coastal |

Consumption rules: concrete cum = area_sqm x (thickness_in x 0.0254) x 1.02; steel kg/cum by element (slab 80, footing 75, beam 120, column 160); cement bags/cum (M20 = 8, M25 = 9.5); turf sqm by roll layout; infill kg; netting sqm + 10%; paint priced per kg of steel (E.2), no separate litre take-off; cable m by pole distance + 10%; tiles sqm + 8%.

### J.4 Exports (Modules 16 and 17)
- **Cost Sheet (Excel, editable)** — all lines, formulas live, cost price, labour, overheads; internal only
- **Material Consumption Sheet (Excel, editable)** — quantities with rates (internal)
- **Vendor RFQ (Excel/PDF)** — item, spec, qty, unit **only**; no rates, no vendor names
- **BOM (Excel)** — internal, categorised, with source AI/Manual
- **Billing Handoff (new, v5.1.12)** — a **"Send to Billing"** button appears on a Quotation once it reaches **Won**. One click produces a PDF/Excel with client name, contact, address, quotation number and date, the payment schedule/milestones (`SCHEDULES`), and the total (GST-inclusive, flat 18% already applied) — nothing else, no cost, no margin, no HSN. This is a manual handoff: NestaPrime downloads it and enters the actual bill in Tally themselves. No API integration, no automatic sync, no new database entity — it's a formatted read of data the Quotation and Schedule already hold

---

## PART K — COMMERCIAL LAYER (Module 12)

### K.1 Calculation order

| Step | Line | Visible to |
|---|---|---|
| 1 | Material subtotal — every take-off quantity x rate, including site-prep items, drainage, base, structure, flooring, lighting, HVAC, accessories, ticked scope items | PM, Director (Sales: quantities and item rates only, no totals — see K.3) |
| 2 | + Labour — activity rate x quantity where a rate card exists, else the line's material cost x its labour category % (J.2) | PM, Director |
| 3 | + Site establishment % of (1+2) + freight + crane hire | PM, Director |
| 4 | + Design & approvals — only items NOT already ticked as scope lines in step 1 (CAR policy and workmen's compensation insurance are priced here and only here) | PM, Director |
| 4A | + Tender overheads (Tender Mode only): BG cost, DLP reserve 1% (replaces the 1% warranty reserve of Appendix B — never both), BOCW cess 1%, tender fee | PM, Director |
| 4B | + Warranty reserve 1% (private clients; Appendix B) | PM, Director |
| 5 | **= COST PRICE (base cost)** | PM, Director |
| 5A | + Company overhead recovery [confirm 10%] of step 5 — office, admin, marketing, vehicles, finance cost; Director sets from last year's accounts, reviewed quarterly | PM, Director |
| 6 | + Contingency at **work-package level**, grouped by each line's `work_package` field (civil 5%, structure 5%, flooring 3%, electrical 3%, pool 8%, hvac 5%, accessories 2%, scope 5%, services 0% [confirm]; the structural engineer fee is a *services* line; lighting fixtures, cabling, panels and earthing are all *electrical*; PM may raise any package to 10% with reason) → **COST INCL. CONTINGENCY** (this is "Cost" in every margin formula) | PM, Director |
| 7–8 | **= SELLING PRICE (ex-GST)**, computed server-side as Cost incl. contingency / (1 − target margin for this client/sport, Q.1) | Sales, PM, Director, client |
| 9 | − Discount (Sales may only request a discount in Rs or %; never a markup). Private clients: one "Special discount" line, unit rates untouched. Tender Mode: discount distributed proportionally into item rates (BOQ rule), no separate line | Sales, PM, Director, client |
| 10 | Margin re-check: margin = (Selling after discount − Cost incl. contingency) / Selling after discount, against the floor (K.2); below floor → Director approval | system, PM, Director |
| 11 | + GST, flat **18%** on the subtotal (steps 1–10 after discount) — see K.1b. No TDS, no per-item HSN classification, no place-of-supply computation happens in this app | Sales, PM, Director, client |
| 12 | **= QUOTATION TOTAL** (GST-inclusive — this is the number the client sees as their all-in cost) | Sales, PM, Director, client |

#### K.1b GST on the quotation (normative, v5.1.9) — flat, inclusive, matches real practice exactly

**This app is a pre-sales pitching and lead-tracking tool, not a billing or tax-compliance system.** v5.1.9 replaces the elaborate per-line GST classification, multi-state place-of-supply computation, separate-goods carve-out and income-tax/GST TDS logic that earlier versions carried (K.1a and the original K.1b, retired — see version history) with the flat calculation NestaPrime's own quotations have always actually used. Reference: `23-A100-Quotation for Squash Court- Sanmati HS School.pdf` (turnkey squash court, 19/04/2023) — line items sum to a subtotal, **GST 18% is shown as one flat line**, the total is presented to the client as GST-inclusive ("GST as applicable is Included in the above Cost"). No HSN codes, no GSTIN, no place-of-supply state, no separate-goods line, and no TDS appear anywhere on that document. This is the pattern the app now implements exactly:

```
Subtotal (after discount, ex-GST)
+ GST 18% (flat, on the subtotal — one line, no item-level classification)
= Total Project Cost (shown to the client as inclusive; nothing further to add)
```

**Everything downstream of a won project — actual invoicing, HSN/SAC classification, place-of-supply determination, TDS deduction by the client, e-way bills for material movement — happens outside this app**, in NestaPrime's existing accounting process (Tally) and, for logistics, through the vendor/NestaPrime-issued e-way bill tied to the Purchase Order (`PURCHASE_ORDERS.eway_bill_no`, already correctly separate from the quotation in Part O). The app does not need to get any of that right, because it never produces the document that has to be right about it — it produces the pitch.

**Supply Only** projects are priced the same way at the quotation stage as turnkey — **one blended ₹/sqft rate covering everything negotiated (material, then labour), not itemized per good**, with GST folded into the total shown to the client (Director confirmed: "client first negotiates material and then labour, so only one sqft rate including all + GST" — there is no separate quotation format for goods-only pricing). The precise HSN classification, if the delivery ever needs it, is confirmed at actual billing, same as everything else.

### K.2 Markup vs margin (defined once)
- **Markup % = (Selling - Cost) / Cost** · **Margin % = (Selling - Cost) / Selling**, where Cost = cost incl. contingency (K.1 step 6) and Selling = selling price after discount (K.1 step 9). Example: cost Rs 8,50,000, selling Rs 10,00,000 → markup 17.6%, margin 15.0%. Floor check uses margin and is re-run whenever discount or cost changes.
- **Target margin** per client type and sport type (Director, Q.1) is what the system prices with; **floor margin** is the minimum below which Director approval is needed. Defaults [confirm]: target = floor + (competitive_segment ? 3 : 5) points, where `competitive_segment` is a per-client-type Master Setting (default TRUE for School, College, Government, Corporate; FALSE for Housing society, Club, Individual; Director may change). These are starting points only — the Director sets the final targets in Master Settings before Phase 1b; a target set too high shows up as frequent discount requests in the override report and should be lowered.
- Floors are set on **margin**; both shown on Director screen. Defaults [confirm]: School 18% · College 18% · Housing society 20% · Corporate 15% · Club 20% · Government 12% · Individual 22%. A sport-type floor (e.g. Pool 15%, PEB 14%) **replaces** the client floor for that sport when the Director has defined one (large-ticket jobs are allowed a lower floor). Multi-sport project: floor = cost-weighted average of the applicable floors.

### K.3 Enforcement and what Sales can see
- Sales needs item quantities and item rates to enter vendor quotes, so Sales sees those. Sales never receives subtotals, cost price, contingency, markup %, margin %, margin Rs or TDS — these fields are **removed at the API by role**, not hidden in the browser, so they cannot appear in any Sales-side export or screen.
- Procurement sees quantities, item rates and line amounts on the consumption sheet, BOM and POs (needed to buy), but never labour, overhead, contingency, cost price totals, selling price or margin — the API strips those for the Procurement role exactly as for Sales.
- Sales never proposes a markup; the system prices from the Director's target margin and Sales can only request a discount (K.1 step 9).
- Honest limit: a Sales user who sees item rates can roughly add them up. If the Director wants Sales fully cost-blind, switch on **Rate-blind mode** (config): Sales enters quantities and attaches vendor quotes as images; PM enters rates. Default is off.
- The hard guarantee is client-side: no client document (Estimate, Quotation, RFQ, BOQ) ever contains cost price, contingency, markup or margin — enforced in the export code.
- Database file kept off shared drives; backups encrypted; attachments stored outside the web root.

---

### K.4 GST on the quotation — why 18% flat (v5.1.9, drastically simplified)

**Director decision, 2026-09 (v5.1.9):** this app is pre-sales quotation and lead-tracking only — not a billing system, not a tax-compliance system, not a financial planning tool. NestaPrime's actual GST returns, TDS deduction, HSN/SAC classification, place-of-supply determination and e-invoicing are handled entirely outside the app, in the existing Tally-based accounting process ("we already did that for us"). The app's job is to give the client an honest, all-in number to pitch against, matching how NestaPrime has always actually quoted.

| Topic | Why 18% flat is the right default | Basis |
|---|---|---|
| Rate on a works contract | **18%**, SAC 9954, on the whole contract value — material and labour are one composite supply, never split. This is why NestaPrime's own historical quotations (turnkey, supply + installation) all show a flat 18% line, and why the app matches that instead of computing per-item rates | Notification 11/2017-CT(R) entry 3(xii); no 5% works-contract entry applies to sports facilities |
| Artificial turf, or any material laid/fixed at site | Part of the works contract → 18%, even though the same material sold loose (as goods) can carry a different HSN rate — this is exactly why the app does not try to classify individual line items; that determination belongs to actual invoicing, not the pitch | AAR *New Horizon Development Co.* (2025): a fixture laid to earth becomes immovable property |
| Everything else — place of supply, GST-TDS, income-tax TDS, ITC eligibility, e-invoicing, HSN/SAC per item, separate-goods classification | **Out of scope for this app.** These are real obligations, but they attach to the actual invoice raised at billing time (Tally), not to the quotation. Nothing in the app computes, displays, or gates on any of them | — |
| E-way bill | Required for material movement above Rs 50,000 per consignment — a procurement/logistics document tied to the PO and delivery, raised by the vendor or NestaPrime against `PURCHASE_ORDERS.eway_bill_no`. Already correctly separate from the quotation in Part O; unaffected by this simplification | CGST Rule 138 |
| Rate change clause | Quotation states "GST at the rate applicable on the date of invoice; any statutory change after the quotation date is to the client's account" | Appendix B |

The GST rate itself (18%) is a Master Setting (Q.1), not hard-coded, in case it ever changes — but nothing else in this table is computed by the app.

## PART L — TENDER MODE (Module 12B, Government clients)

| Element | Behaviour |
|---|---|
| Format | BOQ-style itemised schedule (item no., description, unit, qty, rate, amount) instead of packages; DSR/SOR reference column |
| EMD | Amount & validity tracked; refund reminder |
| Security deposit / retention | 5–10% [confirm] withheld → shown in net receivable |
| Performance bank guarantee | 3–5% of contract, borne by NestaPrime (client requirement). BG cost = BG amount x bank charge [1–2% p.a.] x (contract months + DLP months) / 12 where contract months = ceil(schedule weeks / 4.33), added to cost in K.1 step 4A; never shown as a separate line to the client |
| Defect-liability period | 12 months default; DLP cost 1% reserve |
| Price basis | Inclusive/exclusive GST toggle; L1 mode shows margin at proposed price live; discount is applied as a uniform % on item rates (no separate discount line, per DSR/SOR practice) |
| Statutory | BOCW cess 1% on works > Rs 10 L; GST-TDS 2% by government/PSU payer; tender fee; mobilisation-advance BG if advance taken — all flow into K.1 step 4A / 13 |
| Documents | Technical bid checklist (GST, PAN, turnover, past work certificates, ISO), financial bid PDF |
| Timeline | Bid due date, pre-bid meeting, opening date tracked with reminders |
| Post-award | Work order upload, milestone billing (RA bills), measurement book entry link to actuals |

---

## PART M — DOCUMENT & APPROVAL WORKFLOW (Module 18, new core of v4)

### M.1 The three-document chain

```
 STAGE 1               STAGE 2                          STAGE 3
 COST SHEET   ──►  ESTIMATE (client-facing) ──►  FORMAL QUOTATION  ──►  WORK ORDER / ACTUALS
 (internal)        product options + budget         binding offer
 PM verifies       Client approves product          Director/PM releases
```

| Stage | Document | Purpose | Who prepares | Who approves | Status values |
|---|---|---|---|---|---|
| 1 | **Cost Sheet** (CS-YYMM-####-R#) | Internal cost price with consumption; one per project, with line groups per **sport** and per **option** (Budget / Standard / Premium); basis for everything | Sales / PM | **PM or Director** | Draft → Verified → Superseded (when a new revision is verified); **Unverified** = auto-generated by a skip (rule 3), behaves as Draft for editing but allows the next stage to be created |
| 2 | **Estimate** (EST-YYMM-####-R#) | Client-facing budget per sport with product options (Budget/Standard/Premium), standard-vs-actual, images; used to get **product approval**. Price per option = that option's cost group priced at target margin, shown as a range ± range_pct [confirm 5%] | Sales | Internal: system-checked on **every option** (auto-cleared if margin ≥ floor; Sales never sees the margin) / Director (below floor). External: **Client product approval** (per sport, may be partial) *or* client's **specific demand** recorded | Draft → Sent → Client approved (per sport) / Client demand received / Client rejected / Expired (15 days); a prior revision becomes Superseded |
| 3 | **Formal Quotation** (NPQ-YYMM-####-R#) | Binding offer for the approved sports/options with T&C, payment terms, validity; may cover a subset of the project's sports | Sales | **PM or Director** release; **Director** if discount below floor **or** if the underlying Cost Sheet is Unverified (skipped stage) | Draft → Released → Sent → Won / Lost / Expired (30 days); prior revision Superseded. A **major** edit after Released returns it to Draft (new major revision if it was Sent); a **minor** revision keeps Released/Sent status |
| 4 | Work Order & Actuals | Post-award | PM | Director | Awarded → In progress → Completed |

### M.2 Rules
1. An Estimate cannot be created until its Cost Sheet is **Verified** — *exception:* when a stage is skipped under rule 3, the auto-generated Cost Sheet is Unverified, which permits creation of the next stage but restricts its Release to the Director with the "cost basis unverified" flag (rule 3).
2. A Formal Quotation cannot be created until the Estimate shows **Client approved** *or* **Client demand received** (the client's specific requirement is entered as text + attachments and becomes the basis of the quotation).
3. **Stage omission** (e.g. client wants a quotation directly, or an estimate without a full cost sheet): allowed only via **Skip-stage request** → approved by **PM or Director** → reason logged → the skipped stage is auto-generated in background from defaults and flagged "Unverified" on the internal record. Sales cannot skip alone. A Quotation resting on an Unverified Cost Sheet can be Released only by the Director, carries an internal "cost basis unverified" flag, and cannot be marked Won until the Cost Sheet is verified.
4. **Revisions.** Minor revision (R1.1: typo, client name, contact, wording — no client re-approval, no notification) vs major revision (R2: any priced-content change — client re-approval required). An "edit" that triggers a major revision means a change to priced content: lines, quantities, rates, dimensions, options, terms, validity. Uploading attachments, recording client status, or adding internal notes is **not** an edit. Any edit to a Sent Estimate or Quotation creates a new revision (previous one read-only, PDF shows -R#); a revision of a Sent document keeps the previously frozen rates by default — whoever creates the revision may choose "refresh to current settings". Any edit to a **Verified Cost Sheet** creates CS-R(n+1) in Draft requiring re-verification; every Estimate/Quotation chained to the old revision is flagged "cost basis changed — rebase required" and cannot be Released or Sent until rebased to the new verified revision.
5. Every document freezes its rates, dimensions and attachments at approval time.
6. Client-facing documents (Estimate, Quotation) never carry cost price, markup, margin, contingency, TDS.
7. **Tender Mode exception:** a government tender has no product-approval step. The uploaded tender / NIT / BOQ is recorded automatically as "Client demand received" on the Estimate stage, so the chain runs Cost Sheet → (tender document) → Financial bid. No skip request is needed.
8. **Small-job fast-track:** Resurfacing / Repair jobs below Rs 2,00,000 [confirm] may go Cost Sheet → Quotation with a standing PM pre-approval; logged as a fast-track, not a skip.
9. **Client rejection:** an Estimate can also close as "Client rejected" with a reason (price / scope / timing / competitor) so lost deals are counted at the estimate stage, not only at quotation.
10. **Numbering:** one project number P-YYMM-#### is shared by its Cost Sheet (CS-), Estimate (EST-) and Quotation (NPQ-) so the three documents are traceable. Revisions are stored as `revision_major.revision_minor` and printed as -R1, -R2 (major) and -R1.1, -R1.2 (minor).
11. **Multi-sport projects:** one Cost Sheet with line groups per sport (`lines[].sport_id`) and per option; the Estimate lists each sport with its options; the client may approve some sports and reject others; the Quotation covers the approved subset. Shared structure between adjoining courts is priced with the shared-edge deduction in E.2a.
12. **Overrides by stage (Q.2):** cost-side values (rates, labour %, site establishment %, multipliers, formula constants) can be overridden only on the Cost Sheet before verification; commercial values (discount, payment terms, validity, warranty within limits) only on the Estimate/Quotation. The Quotation never changes cost. GST is not a per-document override — it is a flat, Master-Settings rate (K.4).

### M.3 Attachments & approval evidence
Each stage has an **Attachments panel** (images, PDF, DOCX, XLSX, email .eml, DWG/PDF drawings; max 100 MB each, images auto-compressed to ≤ 5 MB with original kept for drawings/soil reports; project quota 2 GB counted on original files [confirm]; drawings and soil reports are never compressed):
- Cost Sheet: site photos, survey form, vendor quotes (photo/PDF), soil report
- Estimate: product images/catalogues sent to client, layout sketch, **client approval evidence** (signed estimate scan, email screenshot, WhatsApp screenshot) or **client demand document** (their specification/drawing/tender)
- Quotation: signed quotation, purchase order/work order, client GST certificate
- Actuals: delivery challans, invoices, site progress photos

A stage cannot move to its approved status without at least one attachment tagged **`approval_evidence`** unless PM/Director waives it (logged). Attachments are versioned and included in the audit log.

**Evidence integrity.** Every attachment is stored write-once (no overwrite, no delete — only supersede) with its SHA-256 hash, uploader, timestamp and IP in the audit log, so it can be shown unchanged in a dispute. **Approval strength** recorded per evidence: *Formal* (e-signed estimate/quotation via Aadhaar e-sign or DocuSign, signed scan on client letterhead, purchase/work order, tender committee letter) or *Informal* (WhatsApp/email screenshot with timestamp and sender visible). A verbal confirmation is recorded only as an *internal_note* for CRM purposes; it is **not** evidence and cannot move a document beyond Draft. Government / Tender Mode and any quotation above Rs 25 L [confirm] require **Formal** evidence before "Won"; Informal evidence is accepted to move an Estimate to "Client approved" but the Quotation PDF then carries a signature block that must come back Formal. The approver's name and designation are recorded and checked against the client master's authorised signatories.

**Rejection and rework.** Every approval step has a **Reject → Rework** path with a reason category (wrong quantities / rate not confirmed / margin / scope unclear / evidence missing / other) and a note; the document returns to Draft with the reason visible on the Sales dashboard.

**SLA timers.** Cost Sheet verification 1 working day, quotation release 1 working day, Director approvals 1 working day [confirm]; breach → reminder to the approver, then escalation to Director (or to the second Director/owner) with the item shown in red on the dashboard.

### M.4 Approval matrix

| Action | Sales | PM | Director | Procurement | Site Engineer | CA / Tax |
|---|---|---|---|---|---|---|
| Create cost sheet / estimate / quotation | ✔ | ✔ | ✔ | ✖ | ✖ | ✖ |
| Send Estimate / Quotation to client; record Client approved / demand / rejected | ✔ | ✔ | ✔ | ✖ | ✖ | ✖ |
| Edit commercial terms on a quotation within Director limits | ✔ | ✔ | ✔ | ✖ | ✖ | ✖ |
| Request discount | ✔ | ✔ | ✔ | ✖ | ✖ | ✖ |
| Verify cost sheet | ✖ | ✔ | ✔ | ✖ | ✖ | ✖ |
| Enter Manual item rate on a Cost Sheet (= propose vendor rate) | ✔ | ✔ | ✔ | ✔ | ✖ | ✖ |
| Confirm PM verification when > 3 categories lack activity rates | ✖ | ✖ | ✔ | ✖ | ✖ | ✖ |
| Confirm vendor rate into database | ✖ | ✔ | ✔ | ✖ | ✖ | ✖ |
| Release quotation (margin ≥ floor) | ✖ | ✔ | ✔ | ✖ | ✖ | ✖ |
| Approve discount below margin floor | ✖ | ✖ | ✔ | ✖ | ✖ | ✖ |
| Skip a stage / fast-track small job | ✖ (requests) | ✔ | ✔ | ✖ | ✖ | ✖ |
| Waive approval evidence | ✖ | ✔ | ✔ | ✖ | ✖ | ✖ |
| Edit Master Settings (rates, %, floors, multipliers) | ✖ | read-only | ✔ | ✖ | ✖ | ✖ |
| Override a cost-side setting on a Cost Sheet before verification (labour %, multipliers, constants) | ✖ | ✔ | ✔ | ✖ | ✖ | ✖ |
| Release a quotation on an Unverified cost sheet | ✖ | ✖ | ✔ | ✖ | ✖ | ✖ |
| View cost price & margin | ✖ | ✔ | ✔ | ✖ | ✖ | ✖ |
| Edit consumption sheet, raise RFQ / PO | ✖ | ✔ | ✔ | ✔ | ✖ | ✖ |
| Enter site survey, actuals, progress photos | ✖ | ✔ | ✔ | ✖ | ✔ | ✖ |
| Mark won/lost + reason | ✔ | ✔ | ✔ | ✖ | ✖ | ✖ |

### M.4a Implementation decisions (answers to the developer-readiness questions)
1. **Cost Sheet verification evidence:** the `approval_evidence` rule applies to Estimate and Quotation only. A Cost Sheet is verified on the PM's action alone; its attachments (survey form, vendor quotes, soil report) are supporting, not gating.
2. **Sports with two standard levels:** one SPORTS_MASTER record per sport with a `levels[]` array (club / tournament / international), each carrying its own build dimensions, minimum height and lux; the user picks the level in Module 1 (default club).
3. **Tender financial bid:** it is the NPQ Quotation record with `gst_mode`, BOQ export and Tender Mode rules applied — not a separate document type.
4. **Phase 1a core sports:** box cricket, football 5-a-side, football 7-a-side, badminton, tennis, pickleball, padel, basketball (outdoor #19), volleyball (outdoor #20), multipurpose; the indoor variants follow in Phase 1b.
5. **Distance:** Phase 1 = PM enters km from the selected HUB; PIN-code distance lookup is a Phase 7 integration.
6. **change_log[]** is a view over AUDIT_LOG filtered by document, not a stored array.
7. **Client status precedence:** ESTIMATE_OPTIONS.client_status is authoritative per option; ESTIMATES.status is derived (approved if any option approved; rejected only if all rejected).
8. **C + D covered court lighting:** truss-mounted under the Type C roof (no poles), per B.1a "Covered shed".
9. *(v5.1.9: item removed — no 194C logic in the app; see K.1b)*

### M.7 Communications (Module 20) — email and WhatsApp for every document; vendor price requests

**Principle:** every document the app generates can be sent from inside the app by **email and/or WhatsApp** in one action, with delivery status and the sent file logged against the document. No document leaves the app by a user attaching it to a personal WhatsApp or mailbox.

#### M.7.1 What can be sent, to whom, by whom

| Document | Recipient | Channels | Who may send | Precondition |
|---|---|---|---|---|
| Estimate PDF | Client contact(s) | Email + WhatsApp | Sales, PM, Director | Status Draft → becomes **Sent** on first send; internal margin check passed |
| Formal Quotation PDF | Client signatories | Email + WhatsApp | Sales, PM, Director | Status **Released** (never Draft); Director release if below floor / unverified cost basis |
| Tender financial bid | Tender authority (as per NIT) | Email (portal upload remains manual) | PM, Director | Tender Mode; Director release |
| *(Billing/RA-bill sending — removed v5.1.9, out of app scope, see Part O `BILLING`)* | — | — | — | — |
| Payment reminder | Client accounts | WhatsApp + email | Sales, PM | Manually raised by Sales/PM — no `BILLING` due-date to auto-trigger from |
| Vendor RFQ (rates-free) | Vendor(s) | Email + WhatsApp | Procurement, PM | RFQ contains item, spec, qty, unit only (J.4) |
| **Vendor price-update request** | Vendor(s) | WhatsApp + email | Procurement, PM, Director | See M.7.3 |
| Purchase order | Vendor | Email + WhatsApp | Procurement, PM | PO approved |
| Site survey form (blank / filled) | Site engineer, client | WhatsApp | PM | — |
| Internal approvals (cost sheet verified, discount approval needed, SLA breach, rebase required) | NestaPrime users | WhatsApp + email + in-app | System | Automatic |
| Cost Sheet, Material Consumption Sheet, internal BOM | **Internal only** | Email to NestaPrime domain addresses only; WhatsApp blocked | PM, Director, Procurement | Never to an external number/address — enforced by recipient-domain check |

#### M.7.2 Rules
1. **Send = event.** Every send creates a MESSAGES record: document id and revision, channel, recipient, sender, template used, attachment hash (same SHA-256 as ATTACHMENTS), provider message id, delivery status (queued / sent / delivered / read / failed / bounced) and timestamps. The document's timeline shows it; the audit log records it.
2. **Only the frozen file is sent.** The PDF sent is the stored, hashed file of that revision — never regenerated at send time — so what the client received can be proved later.
3. **Status transitions on send:** first send of an Estimate → Sent (starts the 15-day validity); first send of a Quotation → Sent (starts 30-day validity). Re-sending the same revision does not change status; sending a new revision supersedes the old one and the message says so.
4. **Recipients come from masters:** client contacts and CLIENT_SIGNATORIES (with role), vendor contacts from VENDOR_MASTER; ad-hoc addresses/numbers need PM approval and are logged.
5. **Consent and opt-out (DPDP Act 2023, WhatsApp policy):** each contact carries `whatsapp_opt_in`, `email_opt_in` and `consent_date`; WhatsApp business messages are sent only to opted-in numbers using approved message templates; every message carries the opt-out instruction; an opt-out is honoured immediately and logged.
6. **Templates:** Director-managed library of message templates per document and channel (subject, body, placeholders such as client name, quotation number, amount, validity, sender). WhatsApp templates are submitted to Meta for approval through the provider; only approved templates are used for business-initiated messages; free-form replies are allowed inside the 24-hour customer-service window.
7. **Internal documents never go outside.** Cost Sheet, consumption sheet, BOM, margin views and Master Settings exports may be emailed only to addresses on the COMPANY domain list and never by WhatsApp; the API rejects any other recipient.
8. **Attachment size:** WhatsApp document limit 100 MB (provider limit applies); larger files are sent as a secure expiring link (7 days, single document, no login for the client, logged when opened).
9. **Failure handling:** failed/bounced messages appear on the sender's dashboard with retry; an Estimate or Quotation whose delivery failed on all channels is shown as "Sent — undelivered" until one channel succeeds.
10. **Inbound replies** (WhatsApp/email) are captured against the same thread: client replies are attached to the document as `client_reply` (informal evidence unless a signed file is attached); vendor replies are parsed per M.7.3.

#### M.7.3 Vendor price-update request (the "ask for a better/current price" flow)
1. From the Rate Sheet (J.1), a stale-rate alert, a commodity alert, or the RFQ screen, Procurement / PM / Director selects one or more items and one or more vendors and chooses **Request price update**.
2. The app sends a templated WhatsApp and/or email: item, specification, quantity band, delivery location (site state), required-by date, requested validity days, and a reply format ("Reply with rate, unit, GST inclusive/exclusive, validity, e.g. `SHS 75x75x2.5 — Rs 68/kg ex-GST, valid 15 days`"). Vendors never see NestaPrime's current rate, other vendors' rates, or any cost/margin figure.
3. The vendor replies on WhatsApp or email. The app captures the reply in the same thread and parses rate, unit, GST basis and validity (the parser proposes; a human confirms). Attachments (vendor quotation PDF/photo) are stored as `vendor_quote` attachments with hash.
4. The captured price is created as an **Unverified rate proposal** in RATES_MASTER (J.1) linked to the vendor, message id and the document that triggered the request; PM or Director confirms it into the master, or applies it as a Manual rate on the open Cost Sheet.
5. Multiple vendor replies for the same item are shown side by side (rate, GST basis, validity, delivery, reliability score) with a **"use this rate"** action; the chosen vendor's reply is linked to the BOM line and later the PO.
6. Reminders: no reply within 2 working days [confirm] → automatic polite follow-up; still none → flagged on the Procurement dashboard.
7. Every request and reply is in the audit log and in the vendor's RATE_HISTORY, so the Director's rate-governance review (J.1) sees when a price was last asked for, not only when it was last changed.

#### M.7.4 Providers and configuration (Master Settings)
- **WhatsApp:** WhatsApp Business Platform (Cloud API) through a Business Solution Provider (e.g. Gupshup, Interakt, Wati, Twilio) [confirm choice]; verified NestaPrime business number; display name and templates approved; inbound webhook for replies and delivery receipts; per-message cost tracked in Master Settings (business-initiated conversation charges).
- **Email:** transactional email service (SendGrid / Amazon SES / Zoho Mail API) with SPF, DKIM and DMARC set on the NestaPrime domain so quotations do not land in spam; sender addresses per role (sales@, procurement@, accounts@); inbound parse for replies.
- **Fallback:** if the provider is down, the app queues the message and offers "download and send manually" while still logging the download.
- **Retention:** message bodies and attachments follow Part O retention (8 years for quotation-related messages).

#### M.7.5 Rights (extends M.4)

| Action | Sales | PM | Director | Procurement | Site Engineer | CA / Tax |
|---|---|---|---|---|---|---|
| Send Estimate / Quotation / payment reminder to client | ✔ | ✔ | ✔ | ✖ | ✖ | ✖ |
| Send bills (BILLING) to client | ✖ | ✔ | ✔ | ✖ | ✖ | ✖ |
| Send RFQ / PO / price-update request to vendor | ✖ | ✔ | ✔ | ✔ | ✖ | ✖ |
| Confirm a vendor reply as a rate proposal | ✖ | ✔ | ✔ | ✔ (proposes) | ✖ | ✖ |
| Email internal documents (domain-restricted) | ✖ | ✔ | ✔ | ✔ (consumption/BOM only) | ✖ | ✖ |
| Manage templates, providers, consent settings | ✖ | ✖ | ✔ | ✖ | ✖ | ✖ |
| Add ad-hoc recipient | ✖ (requests) | ✔ | ✔ | ✔ | ✖ | ✖ |

### M.5 Audit log
`change_log[]` on every document: who, when, field, old → new, reason (for approvals, skips, waivers, discounts). Exportable for Director review.

### M.6 Client-facing document contents

**Estimate PDF:** NestaPrime branding · estimate no. & revision · client details (name, contact, address) · sport(s), dimensions standard vs actual with citation · product options table (Budget/Standard/Premium with images) · indicative price range per option, **GST-inclusive** (K.1b) · inclusions/exclusions · validity 15 days · "Approve option ___ / My requirement: ____" signature block.

**Number format (all client documents):** Rs with Indian grouping (Rs 12,50,000); totals rounded to nearest Rs 10; the quotation total printed in words.

**Formal Quotation PDF** (v5.1.9 — matches NestaPrime's actual historical format, e.g. `23-A100-Quotation for Squash Court- Sanmati HS School.pdf`): quotation no. & revision · client details · itemised particulars (description, area/unit, rate, line total) · **Subtotal** · **GST 18% (flat, one line)** · **Total Project Cost** with a note that GST as applicable is included in the above cost · quotation total in words · payment schedule (template by client type, tied to schedule milestones) · **delivery timeline (from schedule estimator)** · warranty table (flooring, structure, lighting, pool, gym) · standard-vs-actual table · exclusions · standard T&C (starter list in Appendix) · validity 30 days · acceptance signature block. No GSTIN, no place-of-supply state, no HSN/SAC, no separate-goods line, no ITC note — none of that appears on NestaPrime's real quotations and none of it is computed by the app.

---

## PART N — SCHEDULE ESTIMATOR (Module 12A)

| Activity | Duration rule [confirm] | Overlap |
|---|---|---|
| Mobilisation & site prep | 3–7 days | — |
| Base (WBM/PCC/RCC) | 1 day per 1,500 sqft + curing keyed to the flooring going on top: turf on WBM 0 d · turf on PCC 7 d · acrylic/PU on asphalt 14 d · acrylic/PU on PCC 28 d · wooden on PCC 28 d (moisture) · tiles on RCC 14 d | — |
| MS structure fabrication | 1 day per 800 kg (off-site) | parallel with base |
| MS erection & netting | 1 day per 1,000 sqft covered | after curing |
| Turf / flooring | 1 day per 2,500 sqft turf; 1 per 800 sqft wooden; acrylic 8–10 days (coats) | after base |
| Lighting & electrical | 3–5 days | parallel |
| PEB | 4–6 weeks | — |
| Pool | 10–14 weeks | — |
| Handover & testing | 2 days | — |

Output: total weeks, milestone dates → drives payment schedule (e.g. 40% advance · 40% on flooring completion · 20% handover). The payment template prints each milestone as "Rs X + GST Rs Y = Rs Z"; for the advance it adds "GST on advance is remitted to government on receipt" and the cash-flow view (K.1 step 13) shows that outflow in the receipt month.

---

## PART O — DATA ARCHITECTURE

- **SPORTS_MASTER** — fields per C.3
- **FLOORING_MASTER** — id, name, rates_master_item_id (all prices live in RATES_MASTER; master tables never hold their own rate), thickness, warranty_years, category, sub_base_required, shock_pad_rate, roll_width, roll_length, cut_length_allowed, infill_spec, curing_days_by_base, labour_category_id, install_complexity (drives the schedule estimator days/sqft), sports_compatible[], hsn_sac
- **BASE_MASTER**, **STRUCTURE_MASTER** (Types A–G incl. fence; section, wall_thickness, kg_per_m, take-off rule id, warranty_years), **SECTION_WEIGHTS** (E.2), **NETTING_MASTER**, **FIXTURE_MASTER** (W, lm, beam, IP, mounting, rates_master_item_id, warranty), **EQUIPMENT_CATALOGUE** (gym, play, pool), **LABOUR_CATEGORIES** (J.2)
- **RATES_MASTER** — item, category, unit, work_package, labour_category_id, ai_rate, status (verified/unverified), effective_from, source_vendor, source_project, proposed_by, confirmed_by, stale_flag, hsn_sac (validated against the GST HSN/SAC list on entry)
- **RATE_HISTORY** — rate_id, rate, effective_from, effective_to, vendor_id, project_no, changed_by, reason (normalised, one row per change — used by BI)
- **VENDOR_MASTER** — name, city, category, contact, gstin (null = unregistered → no ITC flag), rcm_applicable, payment_terms (printed on PO), reliability_score (from delivery-date variance in PROJECT_ACTUALS; shown on RFQ vendor pick) (rates in RATE_HISTORY)
- **REGIONAL_MULTIPLIERS** — city, labour/transport/material mult, climate_zone, rainfall_zone, coastal, wind_zone, seismic_zone, tariff
- **PACKAGES** — sport, tier, flooring, structure, lighting, scope[], warranty
- **CLIENTS** — name, type, contact, phone, email, billing address, GSTIN (informational only — printed on the quotation if supplied, not used to compute anything), PAN, credit_limit, payment_terms, payment_history, overdue_flag (blocks new Quotation release until Director clears), blacklist_flag (blocks new Estimates), past documents. *(v5.1.9: `is_tds_deductor`, `is_gst_tds_deductor`, `constitution`, `annual_paid_aggregate`, `tds_deducted_this_fy` removed — the app performs no TDS calculation; see K.1b)*
- **COMPANY** — NestaPrime legal name, PAN, bank details, logo, e-invoice applicable flag, turnover band
- **CLIENT_SIGNATORIES** — signatory_id, client_id, name, designation, email, phone, authorization_date, authorization_doc (attachment id), expiry_date, is_active; M.3 approval check = name + designation match an active record whose authorization_date ≤ approval date and expiry_date is null or later
- **COMPANY_REGISTRATIONS** — registration_id, state_code, gstin, registration_date, status (active/inactive), is_primary. *(v5.1.9: retained for reference/Tally export only — the app no longer computes place-of-supply or CGST/SGST-vs-IGST from it; that determination happens at actual billing)*
- **PROJECTS** — setup fields (Part B), site address, site_state_code, sports[], building_status per sport
- **COST_SHEETS** — cs_no, revision, project_no, lines[] (each with sport_id, option, **work_package** — REQUIRED (NOT NULL), enum {civil, structure, flooring, electrical, pool, hvac, accessories, scope, services}; a line cannot be saved without it because contingency grouping (K.1 step 6) depends on it; defaulted from RATES_MASTER.work_package, editable by PM — **NOT NULL; the API rejects a line without it because contingency grouping (K.1 step 6) depends on it; default derived from the item's RATES_MASTER.work_package** — labour_category_id, source AI/Manual, city_of_quote), consumption[], cost_price, cost_incl_contingency, status (Draft / Unverified / Verified / Superseded), auto_generated (bool), verified_by, verified_at, attachments[], change_log[]
- **ESTIMATES** — est_no, revision_major, revision_minor, project_no, cost_sheet_revision_id, status (Draft / Sent / Client approved / Client demand received / Client rejected / Expired / Superseded), rejection_reason, client_demand_text, sent_at, valid_until, approval_evidence[], attachments[], change_log[]
- **QUOTATIONS** — npq_no, revision, project_no, estimate_id, cost_sheet_revision_id, sports_included[], selling_price, discount, **gst_pct (flat, default 18%, K.1b)**, total, released_by, status, cost_basis_unverified_flag, fast_track_flag, lost_reason, competitor, sent_at, valid_until, frozen_rates, attachments[], change_log[]. *(v5.1.9: `gst_mode`, `place_of_supply_state`, `gst_type`, `registration_id_used`, `gst_rate_reference` removed — no per-quotation GST classification is computed)*
- **QUOTATION_LINES** — quotation_id, sport_id, item, spec, qty, unit, sell_rate, amount. *(v5.1.9: `gst_pct`, `hsn_sac`, `separate_goods_invoice`, `itc_eligible_for_client` removed from the line level — GST is a single flat rate on the quotation total, not a per-line classification)*
- **ESTIMATE_OPTIONS** — estimate_id, sport_id, option (Budget/Standard/Premium), cost_group_ref, selling_price, range_low, range_high, client_status
- **SCHEDULES** — document_id, activity, start, duration_days, milestone, payment_pct
- **BILLING** — *(v5.1.9: out of app scope. NestaPrime's actual invoicing, GST returns and TDS bookkeeping run through the existing Tally-based process, not this app. If a lightweight payment-tracking record is wanted later — e.g. milestone, amount received, date — it belongs here as a simple reconciliation entry, not as a system computing tax; no such entity exists yet)*
- **MESSAGES** — message_id, thread_id, document_type, document_id, revision, channel (email / whatsapp / in-app), direction (out / in), template_id, sender_user_id, recipient (contact_id or vendor_contact_id or ad-hoc), attachment_hash, provider_message_id, status (queued / sent / delivered / read / failed / bounced), sent_at, delivered_at, read_at, body_text, parsed_fields (for vendor replies: rate, unit, gst_basis, validity)
- **MESSAGE_TEMPLATES** — template_id, document_type, channel, name, subject, body with placeholders, whatsapp_template_status (draft / submitted / approved / rejected), language, version, active
- **CONTACTS** (client and vendor) — contact_id, parent (client_id / vendor_id), name, role, email, whatsapp_number, whatsapp_opt_in, email_opt_in, consent_date, opt_out_date
- **PRICE_REQUESTS** — request_id, items[] (rates_master_item_id, spec, qty band, site_state), vendor_ids[], requested_by, sent_at, required_by, reply_message_ids[], resulting_rate_proposal_ids[], status (open / replied / closed / expired)
- **SKIP_REQUESTS** — document, stage skipped, requested_by, approved_by, reason, timestamp
- **TENDERS** — project_no, quotation_id, emd, bid dates, retention, BG, DLP, cess, documents[]
- **BOM_LINES** — cost_sheet_revision_id, consumption line ref, item, spec, qty, unit, rate, vendor_id, status
- **RFQS** — rfq_no, vendor_id, lines (item, spec, qty, unit only), sent_at, response
- **PURCHASE_ORDERS** — po_no, vendor_id, bom lines, qty, rate, delivery date, eway_bill_no, received qty, status
- **WORK_ORDERS** — project_no, quotation_id, client work order attachment, awarded_at, status (Awarded / In progress / Completed)
- **HUBS** — hub name, city, state_code (distance km is entered by the PM or computed from PIN via a mapping API in Phase 7; Phase 1 = manual km)
- **PROJECT_ACTUALS** — bom_line actuals, labour, site prep, variance_report
- **ATTACHMENTS** — id, doc_type, doc_id, original_file, original_size, original_sha256, compressed_file (images only, ≤ 5 MB preview), compressed_size, tag ∈ {approval_evidence, client_demand, gst_opinion, structural_design, soil_report, survey_form, vendor_quote, drawing, photo, product_image, signed_document, delivery_challan, invoice, reference}, approval_strength (formal / informal), uploaded_by, uploaded_at, ip, version, superseded_by
- **AUDIT_LOG** — log_id, timestamp, user_id, role, document_type, document_id, field, old_value, new_value, reason, ip, session_id; append-only (insert-only DB role, no update/delete grant), indexed on timestamp and document; retained 8 years
- **SETTINGS** — key, scope (global / city / client_type / sport / package), value, unit, effective_from, changed_by, reference (e.g. CA letter for GST), history[]
- **Retention:** quotations, cost sheets, audit log and evidence 8 years; estimates 3 years; drafts 1 year; attachments moved to cold storage after project completion + 1 year; deletion only by Director with audit entry
- **OVERRIDES** — document_id, setting_key, master_value, override_value, reason, user, timestamp
- **USERS / ROLES** — Sales, PM, Director, Procurement, Site Engineer, **CA / Tax** (read-only on documents; role retained for future use — v5.1.9 removed the tax-setting responsibilities it used to carry, see K.4)
- **REPORTS** (Module 21, Part T) — report_id, report_type ∈ {pipeline, margin, gst}, period_from, period_to, generated_by, status (Draft / Released), source_tables[] (which of the tables above the report was built from), file_hash (SHA-256, same integrity pattern as ATTACHMENTS), change_log[]. A report row is never itself a source of truth — it is a snapshot computed from QUOTATIONS / ESTIMATES / COST_SHEETS / QUOTATION_LINES / BILLING at generation time; re-running the same period after those change produces a new report row, not an edit to the old one

---

## PART P — APP ARCHITECTURE & ROADMAP

### P.1 Stack
React + Vite + Tailwind (frontend, wizard with stage tabs; responsive from day 1 so the site-survey form works on a phone) · Python FastAPI (backend, role-filtered responses) · **PostgreSQL 15+ from day 1** (row-level security by role; no SQLite phase — the migration cost is higher than running Postgres in Docker from the start) · file storage local volume → S3 · React-PDF / SheetJS for exports · Docker on company server → AWS.

**Mobile — PWA, not a separate native app (Director decision, v5.1.14).** One codebase serves web and mobile: a manifest + service worker turn the same React app into an installable PWA — "Add to Home Screen" from the website, no app store, works offline for cached screens. Chosen over a native APK for two reasons specific to this project: (1) a sideloaded APK doesn't auto-update, so a field user could keep quoting off a stale rate or margin floor after Master Settings changes — the PWA always serves the current build; (2) it's the same codebase already being built, not a second app to maintain. iOS was a non-issue either way (Director: no Apple devices on the team), but the reasoning holds independent of that. Native stays an option later only if a specific capability the browser can't do well shows up (background GPS, offline-first sync on poor-signal sites) — nothing identified so far needs it; the site-survey form's photo requirement (Appendix C) works fine through the browser's camera input.

**Security & operations baseline:** TLS 1.3 everywhere; AES-256 encryption at rest for database volume, backups and attachment store; passwords hashed (argon2); role checks server-side only; OWASP Top-10 test (ZAP scan + manual role-matrix test) before each release and a third-party penetration test before Phase 5; CI/CD pipeline (GitHub Actions: lint, unit tests on the calculation engine with the three calibration projects as regression cases, build, deploy with one-click rollback); backups: continuous WAL archiving + nightly full, **RPO 1 hour, RTO 4 hours**, quarterly restore drill.

Frontend components add to v3: `SendDocumentModal` (channels, recipients, template preview), `MessageThread`, `PriceRequestPanel`, `VendorReplyReview`, `MasterSettings`, `OverrideModal`, `CostSheetPanel`, `MaterialConsumptionSheet`, `EstimateBuilder` (options + images), `QuotationBuilder`, `AttachmentPanel`, `SkipStageModal`, `ApprovalQueue`, `TenderPanel`, `ScheduleEstimator`, `FenceSelector`, `NettingSelector`, `AuditLogView`.

### P.2 Roadmap

| Phase | Weeks | Scope | Deliverable |
|---|---|---|---|
| 1a Foundation | 1–2 | PostgreSQL + auth (6 roles), client master, Project Setup, 10 core sports (box cricket, football 5/7, badminton, tennis, pickleball, padel, basketball, volleyball, multipurpose), base, structures A–G with take-off rules, basic engine, **Master Settings loaded with NestaPrime's activity-based labour rate cards and vendor rates (not the [confirm] defaults)**, backups, CI/CD skeleton | Working prototype; 1-project calibration |
| 1b Core expansion | 3–4 | Remaining 20 sports, Excel rate import, rate verification workflow, mobile-responsive site-survey form, 3-project calibration using projects with **verified actual costs** (pass = ±10% on 3/3; if a reference project itself overran, its actuals are used, not its original quote) | Calibrated engine |
| 2 Calculator | 5–6 | Site prep, drainage, MS with weight table, netting, turf rolls/infill, lumen lighting, accessories, scope, deviations | Full cost for any sport |
| 3 Commercial & Documents | 7–8 | Master Settings screen with Excel import/export and override logging, Cost Sheet → Estimate → Quotation chain, attachments & evidence, skip-stage approval, discount approval, target/floor margin, flat 18% GST on the quotation (K.4), audit log, revisions, exports (cost sheet, consumption, RFQ, BOM, CSV), **Communications: email + WhatsApp send of Estimates/Quotations with delivery status, templates, consent**, **PWA (manifest + service worker, installable from the website — moved up from Phase 7, v5.1.14)**; pilot training for 2 senior users at the end of the phase | Production quoting system, installable on mobile |
| 4 Specialty | 9 | Pool, gym, HVAC/acoustics, track, play equipment, natural grass, schedule estimator, side-by-side comparison of two estimate options on one PDF | All 30 sports |
| 5 Tender & rollout | 10–11 | security test (OWASP + third-party pen test), Tender Mode (BOQ export, EMD/BG/DLP/cess, uniform-% discount), purchase orders with e-way bill fields, **vendor RFQ / PO / price-update requests by WhatsApp and email with reply capture into rate proposals, bill and reminder sending**, team training | Full team live |
| 6 Intelligence | Month 3 | Project actuals, variance, profitability by sport/client, vendor performance, win/loss analysis, Director dashboard | BI |
| 7 Scale | Month 4–6 | AWS scale-out, client portal (view/approve estimate online), ERP integration, API — PWA already shipped in Phase 3 | Enterprise |

**Effort note (honest):** Phases 1–5 now span 11 weeks and roughly 500–700 developer hours with two developers (or one developer plus heavy AI-assisted coding); a single developer should plan 16–20 weeks. Calibration against three real projects (Phase 1) is the step most likely to slip — start collecting those three projects' actual costs now.

---

## PART Q — MASTER SETTINGS & OVERRIDES (Module 19)

**Principle:** no rate, percentage, floor or multiplier is hard-coded. Every value marked [confirm] in this document is an *initial default* that lives in **Master Settings**, editable by NestaPrime at any time, and can additionally be **overridden per document** — cost-side values on the Cost Sheet before verification, commercial values on the Estimate/Quotation (M.2 rule 12) — because price and margin change with every deal.

### Q.1 What is configurable and by whom

| Setting group | Examples | Scope | Who edits (Master) | Per-quotation override |
|---|---|---|---|---|
| Material rates | MS pipe Rs/kg, turf Rs/sqm, netting, lights, concrete, glass, pool plant, gym equipment | Global, with city multiplier | Director; PM confirms proposed rates | Sales / PM / Procurement enter Manual rate per item (J.1) |
| Base & structure sanity ranges | WBM/PCC/RCC Rs/sqft, Types A–G Rs/sqft — used only to flag a take-off outside the range (E.2) | Global | Director | — |
| Labour activity rates and fallback % | Rs/sqft, Rs/kg per activity; category % (J.2) | Global, by city | Director | PM per category on the Cost Sheet before verification |
| Site establishment %, overhead %, contingency % by work package | 4–8%, 10%, 3–8% | Global | Director | PM on the Cost Sheet with reason (contingency up to 10% per package) |
| Structural engineer design & sign-off fee | by complexity tier (E.5) | Global | Director | PM on the Cost Sheet with engineer's actual quote |
| Target margin and margin floor | Per client type and sport type (K.2) | Global | Director only | None. Director approves below-floor on the quotation (never edits the floor for one deal) |
| Discount | Rs or % off the system selling price | — | — | Sales requests; system re-checks margin; Director approves below floor |
| Regional multipliers | Labour / transport / material, wind, seismic, coastal, tariff | Per city | Director | PM on the Cost Sheet (e.g. remote site) |
| Freight & crane | Rs/km by vehicle class, truck capacity t, crane day rate | Global | Director | PM on the Cost Sheet |
| Tax | GST rate applied to every quotation, flat, **18% default** (K.4, K.1b) — the app computes no other rate, no per-item HSN, no TDS, no place-of-supply | Global | Director | — (there is nothing to override per quotation; the rate is flat by design) |
| Commercial terms | Payment templates, validity days, warranty years, DLP, retention, BG % | Per client type | Director | Sales edits on the quotation within Director-set limits |
| Packages | Budget / Standard / Premium contents | Per sport | Director | Sales customises items on the estimate |
| Communications | WhatsApp BSP credentials and business number, email provider and sender addresses, template library, consent defaults, follow-up days for price requests, secure-link expiry days, internal-domain list | Global | Director | — |
| Thresholds & modes | Small-job fast-track limit, stale-rate days, deviation amber/red %, attachment size, Rate-blind mode on/off, override-report cadence (monthly) | Global | Director | — |
| Formula constants | Lighting UF/MF, HVAC factors, infill kg/sqm, wastage %, steel kg/cum, curing days, estimate range % | Global | Director (on engineer's advice) | PM on the Cost Sheet with reason |

### Q.2 Rules
1. **Every setting has an effective-from date and history.** Changing a setting never alters an existing Cost Sheet, Estimate or Quotation — they keep the values frozen at their approval (M.2 rule 5). A new revision keeps the previously frozen values by default; whoever creates the revision may choose "refresh to current settings" (same rule as M.2 rule 4).
2. **Override ≠ edit.** An override changes only that document (cost-side on the Cost Sheet, commercial on the Estimate/Quotation — M.2 rule 12) and is logged with user, reason and the master value it replaced; the master value is untouched. The Director sees a monthly "override report" (which settings are overridden most often → candidates for a master update).
3. **Margin floors are the one exception:** they can never be overridden per quotation; going below the floor is a Director approval on that quotation, so floor discipline and deal flexibility are both kept.
4. **Rate updates flow from real deals.** Manual rates entered on cost sheets become "Unverified" proposals (J.1); PM/Director confirmation promotes them to master. Actual purchase rates from Project Actuals (Module 15) generate "update master?" prompts.
5. **Bulk update.** Director can apply a % change to a whole category (e.g. "steel +6%") with one action and an effective date.
6. **Master Settings screen** is Director-only (PM read-only), exportable to Excel and importable back, so NestaPrime can maintain its rate card in Excel if preferred and upload it.
7. Settings changes are in the audit log (M.5).

### Q.3 Reading [confirm] in this document
`[confirm]` = "initial default value, pre-loaded into Master Settings at go-live; NestaPrime replaces it with its own figure before or after launch". None of these values is fixed in code, and none blocks development — the app is built to run on whatever NestaPrime enters.

---

## PART R — APPROVAL CHECKLIST (sign-off before build)

### R.0 Conditions carried from the independent audits (v4.6, v4.8 and v5.1 bottom line)

**Phase 1a is a schema-and-workflow prototype, not a production seed.** Phase 1a code must implement this document's design first, with automated tests. No quotation is issued from Phase 1a until Phase 1b's ordinary QA (does the flat-18% math compute correctly, does the document match K.4/K.1b) is done — that is normal development practice, not a formal sign-off step.

**Resolved in this version (v5.0):** GST-001/DATA-003 multi-state registrations, GST-003 separate-goods safeguards, GST-004 advance GST in cash flow, GST-005 ITC rules, GST-006 billing/IRN table, GST-007 TDS thresholds, and all medium items (work-package field, fallback-labour warning, competitive-segment flag, engineer-override workflow, drainage units, skip-stage exception, attachment originals, evidence types, signatories table, D.1 note, Part S expansion). **Superseded by v5.1.9:** the app was scoped down to pre-sales quotation and lead-tracking only (not billing, not tax compliance), so GST-001 through GST-007's original *machinery* (multi-state registration logic, separate-goods safeguards, TDS thresholds) was removed rather than built — the findings themselves are closed by the app no longer attempting the compliance work they were about, not by implementing it correctly.

**Gate 1 (independent re-audit) removed — Director decision, v5.1.11.** The requirement for an external reviewer to sign off on the built code (`FINAL_RE_AUDIT_ENGAGEMENT_BRIEF.md`) existed because a wrong 194C deduction or a misclassified GST rate carried real compliance risk at scale. That risk no longer exists at this scope. The engagement brief is retained as an informal internal QA checklist (retitled `FINAL_INTERNAL_QA_REFERENCE.md`), not a blocking requirement.

**Gate 2 (bulk rate-card load) also removed as a hard blocker — Director decision, v5.1.13.** The reasoning is the same shape as Gate 1's: the app's actual operating model is manual rate entry per quotation with PM/Director confirmation (J.1), which already works from day one with zero pre-loaded data — a bulk Master Settings load was only ever a convenience (so Sales isn't typing steel ₹/kg from scratch every time), not something the engine needs to function correctly. The Director's own words: rate-card loading happens *"in between working — if we find something not working as per expectation, or [want to] upgrade the app, then we see this"* — i.e. gradually, as real use reveals what's worth pre-loading, not as a prerequisite. **Neither gate now blocks Phase 1b.**

**Recommended, not blocking, per NestaPrime's own pace:**
1. Part R sign-off — a design-acceptance checklist, useful as a record but no longer gating (see above).
2. Vendor rates and labour rate cards in Master Settings — load gradually as real quotations surface what's worth pre-loading; the app runs correctly on 100% manual, per-quotation entries from day one (J.1).
3. Target-margin defaults reviewed and set by the Director (K.2) — the [confirm] default works meanwhile (Q.3: nothing here blocks development).
4. Structural engineer design fee priced in Master Settings (E.5, Q.1) — same as above.
5. Activity-based labour rate cards — same as item 2; the J.2 fallback % covers any category without one yet.

None of the above needs to happen before Phase 1a code is written, tested, and used. **Phase 1b opens on ordinary readiness (working software, no known defects) — not on a formal sign-off list.**

| Item | Verified by (name, role) | Date | Evidence / method | Signature |
|---|---|---|---|---|
| (one row per checklist item below) | | | | |
| **Director final sign-off** | | | | |

- [ ] 30-sport list, run-off dimensions and building-status approach accepted
- [ ] Structure Types A–G, pipe wall-thickness table, netting grades accepted
- [ ] Base matrix and soil triggers (rocky / black cotton / water-logged) verified by engineer
- [ ] Flooring recommendations, roll-based wastage, infill values verified
- [ ] Pool and gym modules match NestaPrime delivery
- [ ] Activity labour rate cards for all eight categories (plus fallback %), site establishment %, overhead %, contingency by package loaded in Master Settings
- [ ] Margin floors by client type entered by Director in Master Settings
- [ ] Master Settings scope and override rules (Part Q) accepted
- [ ] Flat 18% GST-on-quotation rule (K.4, K.1b) accepted — no CA sign-off needed at this scope; the app performs no other tax computation (Director decision, v5.1.9)
- [ ] Three-document chain (Cost Sheet → Estimate → Quotation) and skip-stage rule accepted
- [ ] Approval-evidence attachment rule accepted
- [ ] Tender Mode parameters (retention, BG, DLP) confirmed
- [ ] Payment-term templates and T&C/exclusions text approved
- [ ] Regional multipliers, wind/seismic zones for 10 cities verified
- [ ] Tech stack and deployment path accepted
- [ ] Communications rules (M.7): channels per document, internal-document restriction, consent handling, vendor price-request flow accepted

## PART S — WHAT NESTAPRIME MUST PROVIDE

| # | Item | Priority |
|---|---|---|
| 1 | Current vendor rates to pre-load Master Settings (MS pipe Rs/kg, turf Rs/sqm by grade, nets, lights, concrete, steel, glass, pool plant, gym equipment) — can be supplied as an Excel rate card and updated any time after launch | Critical |
| 2 | Labour activity rate cards (Rs/sqft, Rs/kg) and fallback % per category (initial Master Settings) | Critical |
| 3 | Margin floors by client type (Director enters in Master Settings) | Critical |
| 4 | Existing Excel cost sheets (for import + calibration) and 3 completed projects with actual costs | Critical |
| 4a | Overhead recovery % and its basis (last FY accounts) | Critical |
| 4b | Contingency % per work package | Critical |
| 4c | Structural engineer fee tiers (engineer's rate letter) | Critical |
| 4d | Competitive-segment flags and target-margin gaps per client type | Critical |
| 4e | *(v5.1.9: no longer needed — the app applies a flat 18% GST rate, Director-set, no CA opinion or registration list required)* | — |
| 4f | Fast-track limit, formal-evidence threshold, SLA timers, attachment limits | High |
| 4g | WhatsApp Business number and BSP account, email domain with SPF/DKIM/DMARC access, client and vendor contact lists with opt-in status, approved message wording | High |
| 5 | Sample past estimate, quotation and tender BOQ | High |
| 6 | Logo (SVG/PNG), company details, GSTIN, bank details for PDF | High |
| 7 | Standard T&C, exclusions, warranty terms currently used | High |
| 8 | Cities served and typical distance from hub | Medium |
| 9 | List of vendors with categories | Medium |
| 10 | Sign-off of Part R | Required |

---

## PART T — REPORTING & EXTRACTION (Module 21)

**Principle.** Every report is a computed **snapshot** of existing tables (Part O) — reporting introduces no new source of truth, and no report can show a number that doesn't already exist somewhere in `COST_SHEETS`, `QUOTATIONS`, `QUOTATION_LINES`, `ESTIMATES`, `BILLING` or `PROJECT_ACTUALS`. Internal reports (anything carrying cost, margin, or GST-liability detail) follow the exact same domain-restriction rule as internal documents in M.7.2: they may be emailed only to addresses on the company domain list, never by WhatsApp, and the API rejects any other recipient. A report is generated, not sent — M.7's send/consent rules don't apply to it, but M.7.2's "internal documents never go outside" rule does.

### T.1 Report definitions (first three; more are added the same way)

| Report | Cadence | Source tables | Content | Visible to |
|---|---|---|---|---|
| **Quotation Pipeline** | Weekly | `ESTIMATES`, `QUOTATIONS` | Estimates created and sent in the period (`ESTIMATES.status`, `.sent_at`); quotations released, sent, won, lost, expired (`QUOTATIONS.status`, `.released_at`, `.sent_at`, `.total`); counts and totals by sport and by who released. Quotation totals are shown because K.1 step 12 already marks the total visible to Sales — this report carries nothing Sales doesn't already see on the documents themselves | Sales, PM, Director |
| **Margin Performance** | Monthly | `COST_SHEETS`, `QUOTATIONS`, `OVERRIDES` | Every quotation released in the month: `cost_price` and `cost_incl_contingency` from the linked `COST_SHEETS` revision, `selling_price` and `discount` from `QUOTATIONS`, margin % against the floor that applied (K.2), any below-floor release with its Director-approval reason pulled from `OVERRIDES`/`AUDIT_LOG`. This report carries cost and margin — per K.3 it is never visible to Sales or Procurement, same as the Cost Sheet itself | PM, Director only |
| ~~GST Liability Summary~~ | *(removed, v5.1.9)* | — | Built entirely on `gst_type`, `registration_id_used`, `hsn_sac` and `separate_goods_invoice` — all removed from Part O since the app no longer classifies GST per line or by state. There is nothing left for this report to report on; NestaPrime's actual GST liability is a Tally-side number | — |

Pipeline and Margin are the two that remain. The remaining categories from the original Module 20/21 planning conversation — Win/Loss, Vendor Rate Movement, Project Actuals vs Estimate, Sport-wise Profitability, Override & Calibration, and a Yearly consolidated pack — are not yet specified here; each follows the same pattern (source tables already in Part O, a cadence, a role gate matching K.3/M.7.2) and can be added to this table without a new mechanism.

### T.2 Rules

1. **Period boundaries**, IST (+05:30): Weekly = Monday 00:00 to Sunday 23:59. Monthly = calendar month.
2. **Snapshot, not live.** Generating a report writes one `REPORTS` row with a SHA-256 hash of its output (same integrity pattern as `ATTACHMENTS`, M.3). Re-running the same period later — because a quotation in it later changed revision, for instance — produces a **new** `REPORTS` row; the earlier one is not edited or deleted, so a report can always be shown unchanged in a later dispute, the same guarantee M.3 gives attachments.
3. **Role gate matches the underlying data, not a new permission.** A report is visible to a role only if that role could already see the underlying figures on the source documents (K.3, K.1's per-step visibility column). Margin Performance is PM/Director-only because the Cost Sheet it's built from already is; Pipeline is open to Sales because quotation totals already are.
4. **Release, not send.** A report reaching Director/CA-only content is `Draft` until the Director marks it `Released`; only released reports may be emailed, and only to the internal domain list (T principle, above). This mirrors the Cost Sheet's verification gate (M.2), not the Estimate/Quotation send flow (M.7).
5. **Retention** follows Part O's existing table by what the report is built from: Margin (built from Cost Sheets and Quotations) retains **8 years**, matching those source documents; Pipeline (built from Estimates) retains **3 years**, matching Estimates.

---

## APPENDIX D — Consolidated [confirm] register
Every editable default in this document, in one place. Status is maintained in Master Settings and exported for the Part R sign-off.

| Item | Section | Initial default | Verification method | Owner | Status |
|---|---|---|---|---|---|
| Base cost Rs/sqft WBM / Asphalt / PCC / RCC | D.1 | 45–65 / 80–120 / 55–75 / 85–120 | vendor quotes x3 | PM | Pending |
| Structure sanity ranges Types A–G | E.1 | as table | last 5 projects' actuals | PM | Pending |
| Pipe weights | E.2 | IS 4923 / IS 1239 | supplier catalogue | Procurement | Pending |
| Netting Rs/sqm N1–N4 | E.3 | as table | vendor quotes | Procurement | Pending |
| Flooring rates and warranties | F | master table | vendor quotes + warranty letters | Procurement | Pending |
| Infill kg/sqm by pile | F.5 | as table | turf supplier spec sheet | PM | Pending |
| Line-marking Rs/set | F.6 | 8–25 k | vendor | Procurement | Pending |
| HVAC factors | G.5 | 130 sqft/TR, climate & height factors | HVAC consultant | PM | Pending |
| Lighting UF / MF, lumens per fixture | H | 0.6–0.7 / 0.7–0.8 | lighting vendor photometrics | PM | Pending |
| Labour activity rates / category % | J.2 | as table | last 3 projects' labour bills | PM | Pending |
| Site establishment % | D.4 | 4–8% | project actuals | Director | Pending |
| Overhead recovery % | K.1 5A | 10% | last FY accounts | Director + CA | Pending |
| Contingency by package | K.1 6 | 3–8% | risk review | Director | Pending |
| Target margin and floor by client / sport | K.2 | floor table; target = floor + 3 (competitive) / + 5 | Director decision | Director | Pending |
| Structural engineer design & sign-off fee | E.5, Q.1 | Rs 15k / 35k / 50k+ by tier | engineer's rate letter | Director | Pending |
| GST rate on the quotation | K.4 | 18% flat | Director decision (v5.1.9 — no CA confirmation required at this scope) | Director | Set |
| Estimate range % | M.1 | ±5% | Director | Director | Pending |
| Tender: retention, BG %, bank charge, DLP, cess | L | 5–10% / 3–5% / 1–2% / 12 m / 1% | tender documents, bank | Director | Pending |
| Regional multipliers, wind, seismic, rainfall intensity | B.2, D.3 | 10 cities | IS 875 / IS 1893 maps, IMD | Engineer | Pending |
| Drainage C values, pipe capacity table | D.3 | as table | civil engineer | Engineer | Pending |
| Schedule durations and curing | N | as table | site engineer | PM | Pending |
| Fast-track limit, formal-evidence threshold, arbitration threshold | M.2, M.3, App. B | Rs 2 L / Rs 25 L / Rs 25 L | Director | Director | Pending |
| SLA timers, attachment limits, retention periods | M.3, O | 1 day / 100 MB, 2 GB / 8-3-1 years | Director | Director | Pending |
| Stale-rate days, commodity alert threshold | J.1 | 90 days / ±10% | Director | Director | Pending |
| Communications: BSP choice, follow-up days, secure-link expiry | M.7 | — / 2 working days / 7 days | Director | Director | Pending |

### D.1 *(removed, v5.1.9)*

The separate-goods / non-separable-category mechanism this section defined (`separate_goods_invoice`, the canonical category list, the CA-opinion gate) was a billing-time classification feature. Per the v5.1.9 scope decision, the app does not classify individual line items for GST at all — see K.4. If a future version needs this again (e.g. the app takes on real invoicing), reintroduce it deliberately rather than resurrecting this section as-is, since the surrounding workflow (Director/CA-only flag, attachment requirement) no longer has anything to attach to.

## APPENDIX A — Starter exclusions list
Statutory approvals and fees (obtaining and paying for permissions is the client's responsibility; NestaPrime's own compliance items such as pool-safety signage, lifeguard-requirement note and design NOC documentation are priced as scope lines and are NOT excluded) · civil work outside court build area · electrical connection from grid / transformer · water supply to site boundary · taxes other than GST · price escalation: steel or turf index movement beyond ±10% after the validity date is passed through at documented cost · rock excavation beyond 1 m · dewatering beyond 3 days · night work · items not listed in schedule.

## APPENDIX B — Starter T&C
Validity 30 days · payment schedule as per quotation · delivery timeline from advance and site handover · **Warranty:** coverage per item as per warranty table (manufacturer-backed for turf/flooring/lighting, NestaPrime workmanship for structure and civil); excludes misuse, vandalism, unauthorised repair, lack of specified maintenance (AMC or logged maintenance), flooding, fire, Acts of God; claim by written notice with photos, inspection within 7 working days, repair or replace at NestaPrime's option; warranty reserve 1% of contract held internally · client to provide clear site, power and water · variations charged at quoted unit rates · **Force majeure:** flood, earthquake, cyclone, fire, epidemic/pandemic, war, riot, strike, government order or lockdown, or other event beyond reasonable control; affected party notifies within 7 days; time extended by the duration; neither party liable for delay; either may terminate after 90 continuous days · **Taxes:** GST at the rate applicable on the date of invoice; statutory changes after the quotation date are to the client's account; GST on advances is payable on receipt · **Jurisdiction:** courts at NestaPrime's registered office city (auto-filled from COMPANY settings; Director may change per quotation), arbitration under the Arbitration and Conciliation Act 1996 with a sole arbitrator for disputes above Rs 25 L [confirm].

## APPENDIX C — Site survey form (fields)
Client, site address, PIN, contact · sport(s) & count · available area L × W · slope / level · soil observed · water-logging · access road width · crane access · power (phase, load) · water source · existing structures / trees · neighbour constraints · orientation (N–S preferred for courts) · photos (min 4) · surveyor & date.

---

*End of Unified Master Blueprint v5.1 — App-Ready Baseline*
