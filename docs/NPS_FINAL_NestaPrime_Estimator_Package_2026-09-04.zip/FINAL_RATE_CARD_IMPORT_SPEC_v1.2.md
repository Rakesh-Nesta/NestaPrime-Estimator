# Rate Card & Master Settings Import — Specification (optional, gradual — no longer a gate)

Status: **specification only** — no endpoint exists yet, no schema changes are made by this document.
**Not a Phase 1b prerequisite (v5.1.13):** the app runs correctly on manual, per-quotation rate
entry with PM/Director confirmation from day one (blueprint J.1) — that's the real operating model.
This bulk-import endpoint is a convenience for later, to be built and used whenever it's actually
worth the effort, not something that has to exist before Phase 1b opens.
Spec version: **v1.2**, annotated for blueprint **v5.1.13**: the `Tax_Thresholds` and
`Non_Separable_Categories` sheets this spec originally defined are **retired** — the app's blueprint
scope no longer includes TDS or per-item GST classification (see K.4). See §1 for what's still
active.
This is the design that `POST /master-settings/import` will implement once Phase 1b opens, so that
NestaPrime's rate card, labour rates, GST table, margin floors, vendor master, and company
registrations can be loaded from `NestaPrime_Rate_Card_Import_Template.xlsx` in one pass instead of
one `PUT /settings/{key}` call at a time.

Field names throughout match Blueprint v5.1.13 Part O (`RATES_MASTER`, `VENDOR_MASTER`,
`REGIONAL_MULTIPLIERS`, `COMPANY_REGISTRATIONS`, `RATE_HISTORY`) and Part Q (Q.1 setting-group
ownership, Q.2 rules) exactly, and against the Phase 1a code's own enums
(`backend/app/engine/settings.py::DEFAULTS`, `backend/app/models.py`) so nothing here requires
renaming a field that already exists.

## 1. Scope — nine active sheets, two retired (v5.1.9)

| Sheet | Blueprint anchor | Landing table |
|---|---|---|
| Rates_Master | Part O `RATES_MASTER`, Q.1 "Material rates" | `settings` keys are unaffected; this seeds a new `rates_master` table (not yet built — Phase 1b) |
| Labour_Activity_Rates | J.2, Q.1 "Labour activity rates and fallback %" | `settings["labour.fallback_pct"]` (category-level) + new `labour_activity_rates` table (item-level) |
| Regional_Multipliers | Part O `REGIONAL_MULTIPLIERS`, Q.1 | new `regional_multipliers` table |
| GST_Settings | K.4, Q.1 "Tax" | `settings["gst.works_contract_rate"]` (the flat 18% rate) only — v5.1.9 removed per-HSN rates from this sheet's scope, since the app no longer classifies items by HSN |
| ~~Tax_Thresholds~~ | *(retired, v5.1.9 — the app has no TDS logic; `itds.*` and `gst.tds_*` settings no longer exist)* | — |
| Margin_Floor | K.2, Q.1 "Target margin and margin floor" | `settings["commercial.margin_floor"]`, `settings["commercial.sport_margin_floor"]`, `settings["commercial.competitive_segment"]` |
| Contingency | K.1 step 6, Q.1 | `settings["commercial.contingency_by_package"]`, `settings["commercial.contingency_max"]` |
| Vendor_Master | Part O `VENDOR_MASTER` | new `vendor_master` table |
| Company_Registrations | Part O `COMPANY_REGISTRATIONS` | reference/Tally-export only, v5.1.9 — the app no longer computes place-of-supply from it |
| ~~Non_Separable_Categories~~ | *(retired, v5.1.9 — the separate-goods carve-out and its category list no longer exist; see blueprint Appendix D.1)* | — |
| Structural_Engineer_Fees | Part D.1 structural responsibility rule | new `settings["commercial.structural_engineer_fee"]` (keyed by tier) |

A sheet left empty in the workbook is skipped entirely — nothing is inferred, nothing is zeroed out. The two retired sheets remain present in the template file (so nobody's local copy needs re-downloading) but are marked not-in-use on their own tab and are ignored by the importer regardless of content.

## 2. Validation — two passes, nothing written until confirm

### Pass 1: structural (per row, per sheet)
- Every column marked `*` on the sheet's header is required; a missing required value rejects that
  row with `{sheet, row, column, error: "required"}` and stops validating that row (no downstream
  cross-checks run against a row that already failed structurally).
- Type/format checks: dates parse as `YYYY-MM-DD`; percentages and multipliers parse as numbers in
  their stated range (e.g. `Regional_Multipliers.labour_mult` 0.5–3.0, `Margin_Floor.floor_pct`
  0–1); booleans are exactly `TRUE`/`FALSE`; GSTIN matches the 15-character pattern; enum columns
  (`work_package`, `unit`, `client_type`, `climate_zone`, `type`, `status`, `complexity_tier`, the
  Excel template's own dropdown lists) match one of the allowed values exactly, case-sensitive.

### Pass 2: cross-reference (per sheet, then across sheets)
- `Rates_Master.hsn_sac` must exist either in this file's own `GST_Settings` sheet or in the live
  `gst.hsn_rates` — a material with no GST rate anywhere is rejected, not defaulted.
- `Rates_Master.work_package` must be one of the nine enum values already enforced by
  `COST_SHEETS.lines[].work_package` (NOT NULL, per Part O) — this import cannot introduce a value
  the Cost Sheet API would itself reject later.
- `Rates_Master.city_of_quote` (if not blank/`Global`) is checked against `Regional_Multipliers.city`
  either in this file or already live; a warning (not an error) if it isn't found — provenance
  fields are informational, not load-bearing (see the sheet's own header note).
- `Labour_Activity_Rates`: if `rate_rs` is present, `fallback_pct` on that row is ignored with a
  **warning** (not an error) rather than silently dropped, so the person filling the sheet sees it
  was noticed. If both are blank, that row is an **error**.
- `Company_Registrations`: exactly one row across the whole sheet may have `is_primary = TRUE`; more
  than one is a **file-level error** (the whole sheet is rejected, not just the extra rows — a
  double primary is a correctness bug, not a per-row typo). No two `active` rows may share the same
  `state_code` (mirrors the existing `uq_reg_state` constraint plus the `active` business rule the
  running code already enforces in `gst.decide_gst_type`).
- `Non_Separable_Categories`: **retired, v5.1.9** — see §1.
- `Margin_Floor`: `floor_pct` must be < 1.0; a row with `sport_type` set and `client_type` blank is
  valid (sport-type floor, K.2) and vice versa, but a row with both blank is an **error**.
- `Contingency`: `default_pct <= max_override_pct`, and `max_override_pct` may not exceed the live
  `commercial.contingency_max` (currently 0.10) unless this same import also raises
  `commercial.contingency_max` — flagged as a **change** requiring explicit confirmation either way.
- `Tax_Thresholds`: **retired, v5.1.9** — see §1.

### Effective-from and overlap (§2.1, referenced from the sheets)
- A row whose `effective_from` is in the future is loaded but stays **dormant** — it does not affect
  any calculation until that date arrives (matches Q.2 rule 1: changing a setting never touches
  already-frozen Cost Sheets/Estimates/Quotations).
- Two rows for the same natural key (`item` + `source_vendor` + `city_of_quote` for Rates_Master;
  `category` + `activity` + `city` for Labour_Activity_Rates; `hsn_sac` for GST_Settings, etc.) with
  overlapping or identical `effective_from` are **not** an error — the later `effective_from` wins,
  and if two rows share the exact same date, the row appearing later in the sheet wins, with a
  **warning** naming both row numbers so the discrepancy is visible before it's silently resolved.
- The row that loses an overlap is not discarded — it is written to `RATE_HISTORY` /
  `SETTING_HISTORY` immediately as a superseded entry, exactly as if it had been live and then
  replaced (this keeps one code path for "was live, got replaced" and "arrived already superseded").

## 3. Role gate per sheet (Q.1 "who edits")

The importer is authenticated the same way as every other endpoint (JWT, `require_roles`). The
**file** does not carry a single owner — each **sheet** is checked against the caller's role before
any of its rows are processed; a sheet the caller isn't allowed to touch is rejected as a whole
(`403`, sheet name in the reason) while the rest of the file still validates normally:

| Sheet | Allowed roles | Landing status |
|---|---|---|
| Rates_Master, Labour_Activity_Rates | Director, PM | Director's rows → `Verified` immediately (same authority as a direct Master Settings edit). PM's rows → `Unverified`, pending Director or PM bulk-confirm — identical to a manual rate entered on a Cost Sheet (blueprint line 478/882: "Unverified rates never become defaults"). |
| Regional_Multipliers, Vendor_Master, Structural_Engineer_Fees, Contingency | Director | Applied immediately. |
| GST_Settings | Director | Applied immediately. *(v5.1.9: CA role no longer required — there is no per-quotation tax judgment left to make, just the flat 18% rate.)* |
| Margin_Floor | Director only | Applied immediately. No per-quotation override ever exists for this sheet (Q.2 rule 3) — the import is the only way this value changes outside a direct Master Settings edit. |
| Company_Registrations | Director only | **Not** silently applied — see §5. |

## 4. The validation report (returned before anything is written)

`POST /master-settings/import` (multipart file upload) performs Pass 1 + Pass 2 against a
**transaction that is always rolled back** and returns:

```json
{
  "import_id": "imp_2026-09-05_director_a1b2",
  "summary": {"sheets_processed": 7, "rows_ok": 412, "rows_error": 3, "rows_warning": 9},
  "errors": [
    {"sheet": "Rates_Master", "row": 14, "column": "hsn_sac", "message": "HSN '9999' not found in GST_Settings or live gst.hsn_rates"}
  ],
  "warnings": [
    {"sheet": "Labour_Activity_Rates", "row": 8, "message": "rate_rs present — fallback_pct ('20') on this row will be ignored"}
  ],
  "changes": [
    {"sheet": "Non_Separable_Categories", "category_code": "acoustic_panel", "from": "separable", "to": "non_separable", "reason": "wall-mounted, now treated as fixed fixture"}
  ],
  "confirm_token": "..."
}
```

Nothing is written on this call — `errors` must be empty and every entry in `changes` must be
explicitly acknowledged for `POST /master-settings/import/confirm {import_id, confirm_token,
acknowledged_changes: [...]}` to apply anything. A confirm call with a stale or reused `import_id`
is rejected (the underlying data may have moved since the report was generated) and the caller must
re-run the validation pass.

A successful confirm writes one append-only `AUDIT_LOG` entry per sheet actually changed — user,
role, `import_id`, timestamp, and a JSON summary of rows inserted / updated / superseded for that
sheet — exactly as Q.2 rule 7 requires ("Settings changes are in the audit log"). This is on top of,
not instead of, the per-key `SETTING_HISTORY` / `RATE_HISTORY` rows from §2.1: `AUDIT_LOG` gives the
one-line "what happened in this import", the history tables give the field-level before/after.

## 5. Company_Registrations is deliberately not "just another sheet"

This sheet changes place-of-supply (K.4) for every open project the moment it lands — an inactive
row can flip a state from CGST/SGST to IGST retroactively-looking for any project not yet
Verified. Two extra guards beyond the table in §3:
1. The confirm step for this sheet always lists, per state, the GST type a hypothetical project
   sited there would get **before** and **after** — the same computation
   `tests/test_api_roles_and_gst.py::test_boundary_inactive_registration_yields_igst` exercises —
   so the Director sees the practical effect, not just a row diff.
2. The recommended workflow (stated on the sheet itself and repeated here) is to import this sheet
   **alone**, separately from a combined rate-card load, so its effect is never obscured by nine
   other sheets changing at the same time.

## 6. What is explicitly out of scope for this import

- Anything that reaches a client (Estimates, Quotations, PDFs) — this import only ever touches
  Master Settings / rate-card tables, never a document.
- `Vendor_Master.reliability_score` — system-computed from Project Actuals delivery-date variance;
  a value supplied in the sheet for this column is ignored with a warning, never stored.
- Any row already covered by a more specific live mechanism — e.g. a rate proposed through the
  WhatsApp/email vendor price-update flow (Module 20) lands in `RATES_MASTER` as `Unverified`
  through that flow already; this bulk import is for the initial load and periodic bulk refreshes,
  not a replacement for that per-item flow.

## 7. Template file

`NestaPrime_Rate_Card_Import_Template.xlsx` (same folder) has one tab per sheet above, a
`0_READ_ME_FIRST` tab, header-cell comments carrying the same rules as this document (so the person
filling it in doesn't need to have this file open), dropdown validation on every enum column, and
one italic example row per sheet to be deleted before sending the file back. The dropdown validation
and the eventual parser are both bound to column position and exact header text, so the README tab
carries a bold warning: do not rename, delete, re-order, or insert columns on any sheet — add new
data as new rows only. A renamed or reordered column fails Pass 1 for every row on that sheet, not
just the one that was touched.
