# NestaPrime Estimator — Project Status Snapshot

**Date:** 2026-09-04 (three decisions today: the v5.1.9 scope correction, v5.1.11's Gate 1 removal, v5.1.13's Gate 2 removal)
**Purpose:** A single dated record of where the project actually stands, verified against the files on disk.

## 1. The three decisions, in order

**v5.1.9 — scope correction.** The app is pre-sales quotation and lead-tracking only. Confirmed
against a real NestaPrime quotation: flat 18% GST, one line, GST-inclusive total. TDS, HSN,
place-of-supply, multi-state GST, the separate-goods carve-out — all removed.

**v5.1.11 — Gate 1 (independent re-audit) removed.** The compliance risk that required an external
reviewer no longer exists at v5.1.9's scope. Closed by Director judgment. The old engagement brief
is now `FINAL_INTERNAL_QA_REFERENCE.md` — informal, nothing to sign.

**v5.1.13 — Gate 2 (bulk rate-card load) removed.** Same reasoning: the app already runs correctly
on manual, per-quotation rate entry with PM/Director confirmation (J.1) — that's the real workflow,
already built, from day one. A pre-loaded Master Settings rate card was a speed convenience, never
a requirement. Director's own words: rate-card loading happens *"in between working — if we find
something not working as per expectation, or upgrade the app, then we see this."* Gradual, not a
prerequisite.

## 2. Document versions (current)

| Document | Version | Status |
|---|---|---|
| `FINAL_NESTAPRIME_MASTER_BLUEPRINT_v5.1.13.md` | **v5.1.13** | Current |
| `FINAL_RATE_CARD_IMPORT_SPEC_v1.2.md` | v1.2 | Now describes an optional, gradual load — not a gate |
| `FINAL_NestaPrime_Rate_Card_Import_Template_v1.2.xlsx` | v1.2 | Same — fill in whenever convenient |
| `FINAL_INTERNAL_QA_REFERENCE.md` | — | Informal checklist, not a gate |
| `RETIRED_RE_AUDIT_GUIDE_TDS_ADDENDUM.md` | — | Historical record only |
| `test_gst_logic_tds.py`, `SETTINGS_DEFAULTS_itds_rounding_rule.patch.md` | — | Not carried forward |

## 3. Gate status

| Gate | Status |
|---|---|
| ~~Gate 1 — Independent re-audit~~ | **Removed, v5.1.11** |
| ~~Gate 2 — Bulk rate-card load~~ | **Removed, v5.1.13** |

**Neither gate blocks Phase 1b any more.** The app runs on manual, per-quotation rate entry with
PM/Director confirmation from day one (J.1) — that was always the real operating model.

## 4. What has NOT happened

- No application code has been written or reviewed against a real repository.
- No AWS or other deployment has occurred or been agreed to.
- No client-facing quotation has been, or can be, issued from Phase 1a — Phase 1a itself hasn't
  been built yet. "No gates" means nothing formal blocks starting; it doesn't mean the app exists.

## 5. Hold

No formal hold remains. Phase 1b opens on ordinary readiness — working, tested software — not on a
sign-off list.
