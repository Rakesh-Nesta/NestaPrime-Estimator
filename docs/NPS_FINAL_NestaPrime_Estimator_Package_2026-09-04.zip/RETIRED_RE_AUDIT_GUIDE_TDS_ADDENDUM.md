# RE_AUDIT_GUIDE addendum — TDS thresholds and the s.194C(5) catch-up

## RETIRED at v5.1.9 — not part of the current Gate 1 scope

The Director re-scoped the app to pre-sales quotation and lead-tracking only (v5.1.9); TDS logic,
multi-state GST, and HSN classification were removed from the app entirely rather than perfected —
see `FINAL_NESTAPRIME_MASTER_BLUEPRINT_v5.1.9.md` K.4 and K.1b, and the current
`FINAL_RE_AUDIT_ENGAGEMENT_BRIEF.md`, which replaces this document's role in Gate 1.

**Everything below this line is kept for historical record only** — it documents a real correction
made against v5.1.2's GST-007 finding, and remains accurate as a description of that fix *at the
time*. It is not something a reviewer needs to test today; the code it describes should no longer
exist in the app at all (see the current engagement brief's §2, case G3).

---

**Why this section exists.** Blueprint v5.1.2 and earlier treated the two s.194C thresholds as
cumulative (`payment > 30,000 AND aggregate > 1,00,000`). The statute treats them as alternatives,
and s.194C(5) makes the aggregate test retrospective: once the FY aggregate is breached, tax is due
on the *whole* aggregate, so the breaching payment carries a catch-up for earlier payments that
went undeducted. v5.1.3 corrects this in **K.1a** (normative), **K.4** (summary row) and **Part O**
(`annual_paid_aggregate` FY-scoped, plus the new `tds_deducted_this_fy`). The corrected suite is
`test_gst_logic_tds.py`, 24 cases.

**What the auditor is checking.** Not that the arithmetic runs — that the *thresholds are
alternatives*, that the aggregate is financial-year scoped rather than rolling, and that the
catch-up is present. A build that passes the single-payment cases and fails the catch-up cases is
the exact failure mode this section exists to catch, because it looks correct on any single-payment
test.

---

## A. Single-payment threshold (strict "exceeds")

Client is a TDS deductor, constitution = company (2%), FY aggregate before = ₹0.

| # | Payment (ex-GST) | Expected | Guards against |
|---|---|---|---|
| A1 | ₹30,000 exactly | **Not applicable, ₹0** | `>=` used where the statute says "exceeds" |
| A2 | ₹30,001 | **Applicable**, 2% of ₹30,001 | Off-by-one at the boundary |
| A3 | ₹35,000 | **Applicable, ₹700** | The old AND logic — this returned "not applicable" in v5.1.2 |

A3 is the case in `SALES_TEAM_TEST_CHECKLIST.md` §5. Under v5.1.2 it failed; under v5.1.3 it passes.
If it returns "not applicable", the build is still on the cumulative logic and the re-audit stops here.

## B. FY aggregate threshold (strict "exceeds")

No single payment exceeds ₹30,000, so only the aggregate test can trigger deduction.

| # | Sequence | Expected | Guards against |
|---|---|---|---|
| B1 | 4 × ₹25,000 (aggregate lands on ₹1,00,000) | **Not applicable throughout, ₹0 deducted** | Aggregate test firing at the limit rather than above it |
| B2 | B1 then a further ₹1 (aggregate ₹1,00,001) | **Applicable**, catch-up = 2% × ₹1,00,001 ≈ **₹2,000** | The aggregate test being ignored when every payment is small |

B2 is deliberately extreme: a ₹1 payment carrying ~₹2,000 of TDS is correct under s.194C(5) and is
the clearest signal that the catch-up is implemented rather than approximated.

## C. The catch-up arithmetic

The core of this addendum. Requires multi-payment test data — a single-payment fixture cannot
detect these failures.

| # | Sequence | Expected | Wrong answer to watch for |
|---|---|---|---|
| C1 | ₹25,000 (no deduction), then ₹80,000 | **₹2,100** — 2% of the full ₹1,05,000 aggregate | **₹1,600** (2% of the ₹80,000 payment alone) — under-deducts by ₹500, being the 2% nobody took on the first payment |
| C2 | ₹35,000 (₹700 deducted), then ₹80,000 | **₹1,600** — 2% of ₹1,15,000 less the ₹700 already taken | ₹2,300 — double-deducting the first payment |
| C3 | Aggregate ₹1,50,000, ₹3,000 already deducted, then ₹50,000 | **₹1,000** — the payment's own 2%, nothing more | Any figure above ₹1,000 — re-applying the catch-up after it is settled |

C1 and C2 must be run as a pair. A build that hard-codes `rate × payment` passes C2 by coincidence
(everything above the threshold had already been deducted) and fails only C1.

## D. Financial-year scoping

| # | Setup | Expected | Guards against |
|---|---|---|---|
| D1 | Client with ₹5,00,000 aggregate in the prior FY; first payment of the new FY is ₹25,000 | **Not applicable, ₹0** | A rolling 12-month window instead of an April–March FY |
| D2 | Inspect `CLIENTS.annual_paid_aggregate` and `tds_deducted_this_fy` on 1 April | **Both reset to ₹0** | Aggregates carried across FY boundaries |

## E. Rate and basis

| # | Setup | Expected | Reference |
|---|---|---|---|
| E1 | `constitution` = company or firm, payment ₹50,000 | ₹1,000 (2%) | M.4a item 9 |
| E2 | `constitution` = individual-HUF, payment ₹50,000 | ₹500 (1%) | M.4a item 9 |
| E3 | `constitution` = government or trust | Rate **read from Master Settings**, not a literal in code | Q.1 — no rate is hard-coded |
| E4 | Bill of ₹1,18,000 (₹1,00,000 taxable + 18% GST) | TDS **₹2,000**, not ₹2,360 | CBDT Circular 23/2017 — ex-GST basis |

## F. GST-TDS (CGST s.51) — independent statute

| # | Setup | Expected |
|---|---|---|
| F1 | Government payer, contract value ₹2,50,000 exactly | Not applicable |
| F2 | Government payer, contract value ₹2,50,001 | Applicable, 2% of the payment's ex-GST value |
| F3 | Private company payer, contract value ₹50,00,000 | Not applicable — s.51 binds notified payers only |
| F4 | Government client, contract ₹10,00,000, payment ₹4,00,000 | **Both** deductions apply: 194C ₹8,000 **and** GST-TDS ₹8,000, each on the same ex-GST value |

F4 guards against one deduction absorbing or suppressing the other. They are separate statutes.

## G. Deductions are credits, not costs

| # | Check | Expected |
|---|---|---|
| G1 | Compute cost price for identical projects, one client a deductor and one not | **Identical cost price and margin** — TDS must not appear in cost, contingency or the margin calculation (K.1 step 13: cash-flow view only, not P&L) |
| G2 | Every deduction line in the cash-flow view | Reads "applicable" or "not applicable (…)" with the cause named, and the two causes — not a deductor vs threshold not met — are distinguishable |

## H. Canonical non-separable list (v5.1.3)

| # | Check | Expected |
|---|---|---|
| H1 | Seeded `settings["gst.non_separable_categories"]` vs **Appendix D.1** | Exact match. Appendix D.1 is the only statement of the list in the blueprint; Q.1 and K.4 are pointers |
| H2 | Attempt `separate_goods_invoice` on a **posts** line (goal, net or umpire) | **Blocked.** Posts are sleeve-set or ground-anchored and are non-separable in v5.1.3 — this changed from v5.1.2, where one of the two competing lists allowed them |
| H3 | Attempt it on a scoreboard | Allowed **only** if portable or unbolted; a wall- or structure-bolted scoreboard is blocked |
| H4 | Attempt it on turf or a lighting pole, as Director, with a `gst_opinion` attached | **Blocked regardless** — non-separable is not waivable by attachment |
| H5 | Attempt any of the above as Sales or PM | Blocked outright; flag settable by Director or CA only (K.4 safeguard 1) |

---

## Open item for the CA — TDS rounding

The blueprint does not state a rounding rule for TDS. Case A2 yields ₹600.02 and case B2 ₹2,000.02,
so the question is live rather than theoretical. Common practice is to round the deduction to the
nearest rupee, but the blueprint's only rounding rule (M.6) covers client-document totals to the
nearest ₹10, which is a display rule and should not be applied to a statutory deduction. **Confirm
the rule in writing and record it as a Master Setting before Phase 1b**; until then, an auditor
seeing ₹600.02 versus ₹600 should record it as unresolved rather than as a pass or a fail.

## Evidence to capture for sign-off

- `pytest test_gst_logic_tds.py -v` output, all 24 cases, attached with the run date and the commit hash under test.
- Screenshots of the cash-flow view for **A3**, **C1** and **F4** — the three cases where a wrong build produces a plausible-looking number rather than an obvious error.
- Diff of the seeded `gst.non_separable_categories` against Appendix D.1.
- CA's written confirmation of the OR-threshold reading, the s.194C(5) catch-up and the rounding rule.

## Sign-off

- [ ] Section A–B: both thresholds behave as alternatives, both strict "exceeds"
- [ ] Section C: catch-up present; C1 returns ₹2,100 and not ₹1,600
- [ ] Section D: aggregate is FY-scoped and resets on 1 April
- [ ] Section E: rate driven by `constitution`, read from settings; ex-GST basis
- [ ] Section F: s.51 independent of 194C; both apply to a government client
- [ ] Section G: no TDS reaches cost price or margin
- [ ] Section H: seeded list matches Appendix D.1; posts blocked
- [ ] Rounding rule confirmed by CA and recorded in Master Settings

| Verified by (name, role) | Date | Commit hash under test | Signature |
|---|---|---|---|
| | | | |
